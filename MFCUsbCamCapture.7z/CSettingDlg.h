﻿#pragma once


// CSettingDlg 对话框

class CSettingDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CSettingDlg)

public:
	CSettingDlg(CWnd* pParent, int** size, int width = 0, int height = 0, int fps = 0,int format=0);   // 标准构造函数
	virtual ~CSettingDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_VIDEOSETTING };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
	
public:
	afx_msg void OnBnClickedBtnOk();
	afx_msg void OnBnClickedBtnCancel();

public:

	CComboBox m_cmbSize;
	int** m_i;
	int m_width;
	int m_height;
	int m_format;
	int m_fps;
//	afx_msg void OnDestroy();
//	virtual BOOL OnInitDialog();
	virtual BOOL OnInitDialog();
	afx_msg void OnCbnDropdownComboSize();
protected:
//	afx_msg LRESULT OnSucessed(WPARAM wParam, LPARAM lParam);
//	virtual void PostNcDestroy();
};
