﻿// CSettingDlg.cpp: 实现文件
//

#include "stdafx.h"
#include "MFCUsbCamCapture.h"
#include "CSettingDlg.h"
#include "afxdialogex.h"


// CSettingDlg 对话框

IMPLEMENT_DYNAMIC(CSettingDlg, CDialogEx)

CSettingDlg::CSettingDlg(CWnd* pParent,int ** size,int witdh, int height,int fps,int format)
	: CDialogEx(IDD_VIDEOSETTING, pParent)
{
	m_i = size;
	m_width = witdh;
	m_height = height;
	m_fps = fps;
	m_format = format;
}

CSettingDlg::~CSettingDlg()
{
	
}

void CSettingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_SIZE, m_cmbSize);
}


BEGIN_MESSAGE_MAP(CSettingDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BTN_OK, &CSettingDlg::OnBnClickedBtnOk)
	ON_BN_CLICKED(IDC_BTN_CANCEL, &CSettingDlg::OnBnClickedBtnCancel)
//	ON_WM_DESTROY()
ON_CBN_DROPDOWN(IDC_COMBO_SIZE, &CSettingDlg::OnCbnDropdownComboSize)
//ON_MESSAGE(WM_SUCESSED, &CSettingDlg::OnSucessed)
END_MESSAGE_MAP()


// CSettingDlg 消息处理程序


void CSettingDlg::OnBnClickedBtnOk()
{
	
	CString m_str=" ";
	if(m_cmbSize.GetCount()>0)
	m_cmbSize.GetLBText(m_cmbSize.GetCurSel(), m_str); // 获取选定项的文本内容
	//UpdateData(FALSE);
	GetParent()->SendMessageA(WM_SUCESSCLICK, (WPARAM)&m_str,NULL);
	
	EndDialog(IDOK);
	// TODO: 在此添加控件通知处理程序代码
}


void CSettingDlg::OnBnClickedBtnCancel()
{
	AfxMessageBox(_T("取消键被按下"));
	
	EndDialog(0);
	// TODO: 在此添加控件通知处理程序代码
}




//BOOL CSettingDlg::OnInitDialog()
//{
//	CDialogEx::OnInitDialog();
//	//m_cmbFormat.InsertString(0, _T("asdaw"));
//	// TODO:  在此添加额外的初始化
//
//	return TRUE;  // return TRUE unless you set the focus to a control
//				  // 异常: OCX 属性页应返回 FALSE
//}


BOOL CSettingDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	CString m_str;

	
	for (int i = 0; i < _msize(m_i)/4; i++)
	{
		if (m_i[i][0] != 0 && m_i[i][1] != 0) {
			switch (m_i[i][2])
			{
			case 0:
				m_str.Format("mjpeg %d*%d %d@fps",  m_i[i][0], m_i[i][1], m_i[i][3]);
				break;
			case 1:
				m_str.Format("yuv %d*%d %d@fps", m_i[i][0], m_i[i][1], m_i[i][3]);
				break;
			case 2:
				m_str.Format("h264 %d*%d %d@fps", m_i[i][0], m_i[i][1], m_i[i][3]);
				break;
			case 3:
				m_str.Format("h265 %d*%d %d@fps", m_i[i][0], m_i[i][1], m_i[i][3]);
				break;
			default:
				break;
			}
			
			m_cmbSize.InsertString(i, m_str);
		}
		else
		{
			break;
		}
		if (m_i[i][0] == m_width && m_i[i][1] == m_height&&m_i[i][2]==m_format && m_i[i][3] == m_fps)
			m_cmbSize.SetCurSel(i);
		
		
	}
	if ( m_width==0 && m_height==0||m_cmbSize.GetCurSel()<0)
			m_cmbSize.SetCurSel(0);

	// TODO:  在此添加额外的初始化

	return TRUE;  // return TRUE unless you set the focus to a control
				  // 异常: OCX 属性页应返回 FALSE
}


void CSettingDlg::OnCbnDropdownComboSize()
{
		// TODO: 在此添加控件通知处理程序代码
		CClientDC dc(this);
		int nWitdh = 10;
		int nSaveDC = dc.SaveDC();

		//获取字体信息，
		dc.SelectObject(GetFont());

		//计算最大的显示长度
		for (int i = 0; i < m_cmbSize.GetCount(); i++)
		{
			CString strLable = _T("");
			m_cmbSize.GetLBText(i, strLable);

			nWitdh = max(nWitdh, dc.GetTextExtent(strLable).cx);
		}

		//多增加的冗余宽度
		nWitdh += 20 + 5;

		//设置下拉列表宽度
		m_cmbSize.SetDroppedWidth(nWitdh);
		//恢复实际dc
		dc.RestoreDC(nSaveDC);



	// TODO: 在此添加控件通知处理程序代码
}


//afx_msg LRESULT CSettingDlg::OnSucessed(WPARAM wParam, LPARAM lParam)
//{
//	return 0;
//}


