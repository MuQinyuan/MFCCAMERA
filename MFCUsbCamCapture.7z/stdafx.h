
// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN            // Exclude rarely-used stuff from Windows headers
#endif

#define _CRT_SECURE_NO_WARNINGS
#include "targetver.h"

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS      // some CString constructors will be explicit

// turns off MFC's hiding of some common and often safely ignored warning messages
#define _AFX_ALL_WARNINGS

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions


#include <afxdisp.h>        // MFC Automation classes

#include<vector>
using namespace std;
#ifndef _AFX_NO_OLE_SUPPORT
#include <afxdtctl.h>           // MFC support for Internet Explorer 4 Common Controls
#endif
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>             // MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxcontrolbars.h>     // MFC support for ribbons and control bars

#define WM_SUCESSCLICK WM_USER+50


#include "internals/tsk_thread.h"




#ifdef _UNICODE
#if defined _M_IX86
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_X64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif
#endif


#ifdef _DEBUG
#define KH_DEBUG(x)				{ char szInfo[512] = {0}; strcpy(szInfo, x); OutputDebugString(szInfo); }
#define KH_DEBUG1(x, y)			{ char szInfo[512] = {0}; sprintf(szInfo, x, y); OutputDebugString(szInfo); }
#define KH_DEBUG2(x, y1, y2)	{ char szInfo[512] = {0}; sprintf(szInfo, x, y1, y2); OutputDebugString(szInfo); }
#define KH_DEBUG3(x, y1, y2, y3){ char szInfo[512] = {0}; sprintf(szInfo, x, y1, y2, y3); OutputDebugString(szInfo); }
#define KH_DEBUG4(x, y1, y2, y3, y4){ char szInfo[512] = {0}; sprintf(szInfo, x, y1, y2, y3, y4); OutputDebugString(szInfo); }
#else
#define KH_DEBUG(x)	{}			
#define KH_DEBUG1(x, y)	{}		
#define KH_DEBUG2(x, y1, y2) {}	
#define KH_DEBUG3(x, y1, y2, y3) {}
#define KH_DEBUG4(x, y1, y2, y3, y4) {}
#endif


#define TSK_DEBUG_INFO(FMT, ...)		fprintf(stderr, "*[DOUBANGO INFO]: " FMT "\n", ##__VA_ARGS__);
#define TSK_DEBUG_WARN(FMT, ...)		fprintf(stderr, "*[DOUBANGO INFO]: " FMT "\n", ##__VA_ARGS__);
#define TSK_DEBUG_ERROR(FMT, ...)		fprintf(stderr, "*[DOUBANGO INFO]: " FMT "\n", ##__VA_ARGS__);




typedef int tsk_ssize_t; /**< Signed size */
#if defined (_SIZE_T_DEFINED) || defined(_SIZE_T)
typedef size_t tsk_size_t;
#else
typedef unsigned int tsk_size_t;
#endif


//// Windows (XP/Vista/7/CE and Windows Mobile) macro definition.
//#if defined(WIN32)|| defined(_WIN32) || defined(_WIN32_WCE)
//#	define TSK_UNDER_WINDOWS	1
//#	if defined(_WIN32_WCE) || defined(UNDER_CE)
//#		define TSK_UNDER_WINDOWS_CE	1
//#		define TSK_STDCALL			__cdecl
//#	else
//#		define TSK_STDCALL __stdcall
//#	endif
//#	if defined(WINAPI_FAMILY) && (WINAPI_FAMILY == WINAPI_FAMILY_PHONE_APP || WINAPI_FAMILY == WINAPI_FAMILY_APP)
//#		define TSK_UNDER_WINDOWS_RT		1
//#	endif
//#else
//#	define TSK_STDCALL
//#endif


