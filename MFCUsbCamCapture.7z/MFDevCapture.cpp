#include "stdafx.h"
#include "MFDevCapture.h"

#include <Initguid.h>
DEFINE_GUID( PLUGIN_MF_LOW_LATENCY,	0x9c27891a, 0xed7a, 0x40e1, 0x88, 0xe8, 0xb2, 0x27, 0x27, 0xa0, 0x24, 0xee );


CMFDevCapture::CMFDevCapture()
{
//	encoder.codec_id = tmedia_codec_id_none; // means RAW frames as input
	m_chroma = tmedia_chroma_nv12;
	m_fps = 30;
	m_width = 1280;
	m_height = 720;
	m_format = 0;//mjpeg

	m_bStarted = false;
	m_bPrepared = false;
	//m_bMuted = false;

	m_pSession = NULL;
	m_ppTread[0] = NULL;
	m_hWndPreview = NULL;
	m_hMsgParentWnd = NULL;
	//m_bitrate_bps = 0; // used when encoder bundled only

	m_pDeviceList = NULL;
	m_pDeviceAudio = NULL;
//	m_pEncoder = NULL;
	m_pSource = NULL;
	m_pGrabberCB = NULL;
	m_pSinkGrabber = NULL;
	m_pSinkActivatePreview = NULL;
	m_pWatcherPreview = NULL;
	m_pTopology = NULL;
	m_pGrabberInputType = NULL;

}


CMFDevCapture::~CMFDevCapture()
{

}

HRESULT	CopyAttribute(IMFAttributes* pSrc, IMFAttributes* pDest, const GUID& key)
{
	PROPVARIANT var;
	PropVariantInit(&var);

	HRESULT hr = S_OK;

	hr = pSrc->GetItem(key, &var);
	if (SUCCEEDED(hr))
	{
		hr = pDest->SetItem(key, var);
	}

	PropVariantClear(&var);
	return hr;
}
int CMFDevCapture::AudioInit(int iDeviceIndex) {

	MFUtils::Startup();
	HRESULT hr = S_OK;
	IMFMediaSource* m_pAudioSource;
	IMFMediaType* pGrabberNegotiatedInputMedia = NULL;
	IMFMediaType* pType = NULL;
	IMFPresentationDescriptor* pPD = NULL;
	IMFStreamDescriptor* pSD = NULL;
	IMFMediaTypeHandler* pHandler = NULL;
	IMFSourceReader* pSourceReader = NULL;
	IMFActivate* pActivate = NULL;
	
	if (!m_pDeviceAudio && !(m_pDeviceAudio = new DeviceListAudio())) {
		//dzlog_error("plugin_win_mf_producer_video_prepare(), Failed to create device list. self: %08x !!!", pSelf);
		hr = E_OUTOFMEMORY;
		goto  bail;
	}
	// enumerate devices
	hr = m_pDeviceAudio->EnumerateDevices();
	
	if (!SUCCEEDED(hr)) {
		//dzlog_error("plugin_win_mf_producer_video_prepare(), Failed to enumerate devices. self: %08x !!!", pSelf);
		goto bail;
	}

	// check if we have at least one MF video source connected to the PC
	if (m_pDeviceAudio->Count() == 0) {
		//TSK_DEBUG_WARN("No MF video source could be found...no video will be sent");
		// do not break the negotiation as one-way video connection is a valid use-case
	}
	else {
		
		hr = m_pDeviceAudio->GetDeviceAt(&pActivate, iDeviceIndex);//iDeviceIndex�豸����

		if (!SUCCEEDED(hr) || !pActivate) {
			//dzlog_error("plugin_win_mf_producer_video_prepare(), Failed to get best MF video source. self: %08x !!!", pSelf);
			if (!pActivate) {
				hr = E_OUTOFMEMORY;
			}
			goto bail;
		}
		hr = pActivate->ActivateObject(
			__uuidof(IMFMediaSource),
			(void**)&m_pAudioSource
		);
		
		if (!SUCCEEDED(hr)) {
			//dzlog_error("plugin_win_mf_producer_video_prepare(), ActivateObject(MF video source) failed. self: %08x !!!", pSelf);
			goto bail;

		}
		MFUtils::CreatePCMAudioType(48000, 16, 2, &pGrabberNegotiatedInputMedia);
		GUID inputMajorType;
		DWORD cStreams = 0;
		GUID subTpye;
#if 0
		CHECK_HR(hr = pGrabberNegotiatedInputMedia->GetMajorType(&inputMajorType));
		CHECK_HR(hr = m_pAudioSource->CreatePresentationDescriptor(&pPD));
		CHECK_HR(hr = pPD->GetStreamDescriptorCount(&cStreams));

		for (DWORD i = 0; i < cStreams; i++)
		{
			BOOL fSelected = FALSE;
			GUID majorType;
			hr = pPD->GetStreamDescriptorByIndex(i, &fSelected, &pSD);
			hr = pSD->GetMediaTypeHandler(&pHandler);
			hr = pHandler->GetMajorType(&majorType);
			DWORD cType=0;
				pHandler->GetMediaTypeCount(&cType);
				for (DWORD i = 0; i < cType; i++) {
				
					pHandler->GetMediaTypeByIndex(i, &pType);
					pType->GetGUID(MF_MT_SUBTYPE,&subTpye);
					if (subTpye == MFAudioFormat_PCM) 
					{
						pHandler->SetCurrentMediaType(pType);
						
					}
				
				}
			if (majorType == inputMajorType && fSelected) {

				break;
			}
		}
#endif
		CHECK_HR(hr = MFCreateSourceReaderFromMediaSource(m_pAudioSource, NULL, &pSourceReader));
		
		
		pSourceReader->SetCurrentMediaType((DWORD)MF_SOURCE_READER_FIRST_AUDIO_STREAM, NULL, pGrabberNegotiatedInputMedia);

	
		
		
		DWORD index = 0;
		DWORD flag = 0;
		DWORD sink_stream = 0;
		LONGLONG timestamp = 0;
		
		
		CFile file;
		file.Open("./test.pcm",CFile::modeCreate | CFile::modeWrite|CFile::typeBinary, NULL);
		int number = 100;
		while (number--)
		{
			
			IMFSample* sample;
			CHECK_HR(hr = pSourceReader->ReadSample(MF_SOURCE_READER_FIRST_AUDIO_STREAM, 0, &index, &flag, &timestamp, &sample));
			
			if (sample)
			{
				DWORD count = 0;
				BYTE* data;
				DWORD len;
				IMFMediaBuffer* buffer = NULL;
				sample->GetBufferCount(&count);
				
				for (int i = 0; i < count; i++)
				{
					sample->GetBufferByIndex(i, &buffer);
		
					if (buffer)
					{
						hr = buffer->Lock(&data, NULL, &len);
					
						file.Write(data, len);
						hr = buffer->Unlock();
						buffer->Release();
					}
				}
				sample->Release();
			}

		}
		//file.Close();
	}
bail:
		
		SafeRelease(&pActivate);
		SafeRelease(&m_pAudioSource);
		SafeRelease(&pSourceReader);
		SafeRelease(&pGrabberNegotiatedInputMedia);
		SafeRelease(&pHandler);
	
	return 0;
}

int CMFDevCapture::MFInit( int iDeviceIndex, HWND hPlayeWnd , int width, int height,int fps,int format, int iRotation )
{
	MFUtils::Startup();
	//dzlog_info("plugin_win_mf_producer_video_prepare(). self: %08x !!!", pSelf);
	m_hWndPreview = hPlayeWnd;
	//if ( !codec && codec->plugin) {
	//	//dzlog_error("plugin_win_mf_producer_video_prepare(), Invalid parameter. self: %08x !!!", pSelf);
	//	return -1;
	//}
	if (m_bPrepared) {
		//dzlog_warn("plugin_win_mf_producer_video_prepare(), MF video producer already prepared. self: %08x !!!", pSelf);
		return -1;
	}

	// FIXME: DirectShow requires flipping but not MF
	// The Core library always tries to flip when OSType==Win32. Must be changed
	//TMEDIA_CODEC_VIDEO( codec )->out.flip = tsk_false;
	//TMEDIA_PRODUCER( pSelf )->video.fps = TMEDIA_CODEC_VIDEO( codec )->out.fps;
	//TMEDIA_PRODUCER( pSelf )->video.width = TMEDIA_CODEC_VIDEO( codec )->out.width;
	//TMEDIA_PRODUCER( pSelf )->video.height = TMEDIA_CODEC_VIDEO( codec )->out.height;
	//TMEDIA_PRODUCER( pSelf )->encoder.codec_id = tmedia_codec_id_none; // means RAW frames as input

	
	HRESULT hr = S_OK;
	IMFAttributes* pSessionAttributes = NULL;
	IMFTopology *pTopology = NULL;
	IMFMediaSink* pEvr = NULL;
	IMFMediaType* pEncoderInputType = NULL;
	IMFTopologyNode *pNodeGrabber = NULL;
	IMFMediaType* pGrabberNegotiatedInputMedia = NULL;
	BOOL bVideoProcessorIsSupported = FALSE;
	const VideoSubTypeGuidPair *pcPreferredSubTypeGuidPair = NULL;
#if 1
	// create device list object
	if (!m_pDeviceList && !(m_pDeviceList = new DeviceListVideo())) {
		//dzlog_error("plugin_win_mf_producer_video_prepare(), Failed to create device list. self: %08x !!!", pSelf);
		hr = E_OUTOFMEMORY;
		goto  bail;
	}
	// enumerate devices
	hr = m_pDeviceList->EnumerateDevices();
	if (!SUCCEEDED( hr )) {
		//dzlog_error("plugin_win_mf_producer_video_prepare(), Failed to enumerate devices. self: %08x !!!", pSelf);
		goto bail;
	}

	// check if we have at least one MF video source connected to the PC
	if (m_pDeviceList->Count() == 0) {
		//TSK_DEBUG_WARN("No MF video source could be found...no video will be sent");
		// do not break the negotiation as one-way video connection is a valid use-case
	}
	else {
#endif
		// Get best MF video source
		IMFActivate* pActivate = NULL;
		hr = m_pDeviceList->GetDeviceAt(&pActivate, iDeviceIndex);//iDeviceIndex�豸����

		if (!SUCCEEDED(hr) || !pActivate) {
			//dzlog_error("plugin_win_mf_producer_video_prepare(), Failed to get best MF video source. self: %08x !!!", pSelf);
			if (!pActivate) {
				hr = E_OUTOFMEMORY;
			}
			goto bail;
		}


		// Create the media source for the device.
		hr = pActivate->ActivateObject(
			__uuidof(IMFMediaSource),
			(void**)&m_pSource
		);
		SafeRelease(&pActivate);
		if (!SUCCEEDED(hr)) {
			//dzlog_error("plugin_win_mf_producer_video_prepare(), ActivateObject(MF video source) failed. self: %08x !!!", pSelf);
			goto bail;
		}

		// Check whether video processor (http://msdn.microsoft.com/en-us/library/windows/desktop/hh162913(v=vs.85).aspx) is supported
		CHECK_HR(hr = MFUtils::IsVideoProcessorSupported(&bVideoProcessorIsSupported));

		// Must not be set because not supported by Frame Rate Converter DSP (http://msdn.microsoft.com/en-us/library/windows/desktop/ff819100(v=vs.85).aspx).aspx) because of color (neither I420 nor NV12)
		// Video Processor (http://msdn.microsoft.com/en-us/library/windows/desktop/hh162913(v=vs.85).aspx) supports both NV12 and I420


		if (!bVideoProcessorIsSupported)
		{
			
			UINT32 nWidth, nHeight, nFps;
			hr = MFUtils::GetBestFormat(
				m_pSource,
				&MFVideoFormat_YUY2,
				//&MFVideoFormat_H264,
				//&MFVideoFormat_RGB24,
				m_width,
				m_height,
				m_fps,
				&nWidth,
				&nHeight,
				&nFps,
				&pcPreferredSubTypeGuidPair
			);
			if (SUCCEEDED(hr)) {
				//TSK_DEBUG_INFO("Video processor not supported...using source fps=%u, width=%u, height=%u", nFps, nWidth, nHeight);
				m_width = nWidth;
				m_height = nHeight;
				m_fps = nFps;
			
			}
		}

		// Set session attributes/���ûỰ����
		CHECK_HR(hr = MFCreateAttributes(&pSessionAttributes, 1));
		CHECK_HR(hr = pSessionAttributes->SetUINT32(PLUGIN_MF_LOW_LATENCY, 1));

		// Configure the media type that the Sample Grabber will receive.
		// Setting the major and subtype is usually enough for the topology loader
		// to resolve the topology.
		//���ò��������յ�ý�����͡�
		//���������ͺ������Ͷ������˼�������˵ͨ�����㹻��
		//�������ˡ�

		CHECK_HR(hr = MFCreateMediaType(&m_pGrabberInputType));
		CHECK_HR(hr = m_pGrabberInputType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video));
		CHECK_HR(hr = m_pGrabberInputType->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive));
		//����ת�Ƕ�
		//CHECK_HR(hr = m_pGrabberInputType->SetUINT32(MF_MT_VIDEO_ROTATION, iRotation)); //MFVideoRotationFormat_180
		//���÷ֱ���֡��
		/**/
		CHECK_HR(hr = MFSetAttributeSize(m_pGrabberInputType, MF_MT_FRAME_SIZE, m_width, m_height));
		CHECK_HR(hr = MFSetAttributeRatio(m_pGrabberInputType, MF_MT_FRAME_RATE, m_fps, 1));
		
		CHECK_HR(hr = MFSetAttributeRatio(m_pGrabberInputType, MF_MT_PIXEL_ASPECT_RATIO, 1, 1));

		//CHECK_HR(hr = pSelf->pGrabberInputType->SetUINT32(MF_MT_ALL_SAMPLES_INDEPENDENT, pSelf->pEncoder ? FALSE : TRUE));
		CHECK_HR(hr = m_pGrabberInputType->SetUINT32(MF_MT_ALL_SAMPLES_INDEPENDENT, TRUE));
		//CHECK_HR(hr = pSelf->pGrabberInputType->SetUINT32(MF_MT_FIXED_SIZE_SAMPLES, pSelf->pEncoder ? FALSE : TRUE));
		CHECK_HR(hr = m_pGrabberInputType->SetUINT32(MF_MT_FIXED_SIZE_SAMPLES, TRUE));
		
		// Video Processors will be inserted in the topology if the source cannot produce I420 frames
		// IMPORTANT: Must not be NV12 because not supported by Video Resizer DSP (http://msdn.microsoft.com/en-us/library/windows/desktop/ff819491(v=vs.85).aspx)
		CHECK_HR(hr = m_pGrabberInputType->SetGUID(MF_MT_SUBTYPE, pcPreferredSubTypeGuidPair ? pcPreferredSubTypeGuidPair->fourcc : MFVideoFormat_I420));
		//CHECK_HR(hr = pSelf->pGrabberInputType->SetGUID(MF_MT_SUBTYPE, pcPreferredSubTypeGuidPair ? pcPreferredSubTypeGuidPair->fourcc : MFVideoFormat_RGB24));
		m_chroma = pcPreferredSubTypeGuidPair ? pcPreferredSubTypeGuidPair->chroma : tmedia_chroma_yuv420p;
		//TMEDIA_PRODUCER(pSelf)->video.chroma = pcPreferredSubTypeGuidPair ? pcPreferredSubTypeGuidPair->chroma : tmedia_chroma_rgb24;
		//TSK_DEBUG_INFO("MF video producer chroma = %d", TMEDIA_PRODUCER(pSelf)->video.chroma);
		
		// Create the sample grabber sink.��Ƶ�������������뵽������
		CHECK_HR(hr = SampleGrabberCB::CreateInstance((IMFMediaDataPro*)this, &m_pGrabberCB));
		CHECK_HR(hr = MFCreateSampleGrabberSinkActivate(m_pGrabberInputType, m_pGrabberCB, &m_pSinkGrabber));//�����GRABER��Sink��������
		//if (NULL == pSelf->hWndPreview)
		//{
		//	pSelf->pCallback->SetMute(true);
		//}

		// To run as fast as possible, set this attribute (requires Windows 7):Ϊ�˾����ܿ�����У������������(��ҪWindows 7):
		CHECK_HR(hr = m_pSinkGrabber->SetUINT32(MF_SAMPLEGRABBERSINK_IGNORE_CLOCK, TRUE));
 
		// Create the Media Session.����ý��Ự��
		CHECK_HR(hr = MFCreateMediaSession(pSessionAttributes, &m_pSession));

		// Create the EVR activation object for the preview.ΪԤ������EVR�������
		CHECK_HR(hr = MFCreateVideoRendererActivate(m_hWndPreview, &m_pSinkActivatePreview));

		//CHECK_HR( hr = CoCreateInstance( CLSID_GrayscaleMFT, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&m_pGrayscale))); //������Լ���һ��Transe���ز����뵽��������

		if (width == 0 && height == 0) {
			width = m_width;
			height = m_height;
			format = m_format;
			fps = m_fps;
		}
		else
		{
			m_width=width ;
			m_height=height;
			m_format=format;
			m_fps=fps;
		}
		// Create the topology.
	
		CHECK_HR(hr = MFUtils::CreateTopology(
			m_pSource,
			NULL,
			m_pSinkGrabber,
			m_pSinkActivatePreview,
			m_pGrabberInputType,
			&pTopology,
			true,
			width,
			height,
			fps,
			format));
		
		// Resolve topology (adds video p8rocessors if needed).
		CHECK_HR(hr = MFUtils::ResolveTopology(pTopology, &m_pTopology));
		// Find EVR for the preview.
		//CHECK_HR(hr = MFUtils::FindNodeObject(m_pTopology, MFUtils::g_ullTopoIdSinkPreview, (void**)&pEvr));

		
#if 0
		// Find negotiated media and update producer
		UINT32 nNegWidth = width, nNegHeight = height, nNegNumeratorFps = fps, nNegDenominatorFps = 1;
		GUID subtype;
		CHECK_HR(hr = m_pTopology->GetNodeByID(MFUtils::g_ullTopoIdSinkMain, &pNodeGrabber));
		CHECK_HR(hr = pNodeGrabber->GetInputPrefType(0, &pGrabberNegotiatedInputMedia));
		hr = MFGetAttributeSize(pGrabberNegotiatedInputMedia, MF_MT_FRAME_SIZE, &nNegWidth, &nNegHeight);
		if (SUCCEEDED(hr)) {
			m_width = nNegWidth;
			m_height = nNegHeight;
		}
		hr = pGrabberNegotiatedInputMedia->GetGUID(MF_MT_SUBTYPE, &subtype);
		if (SUCCEEDED(hr)) {
			if (MFVideoFormat_YUY2 == subtype)
				m_format = 1;
			else if (MFVideoFormat_MJPG == subtype)
				m_format = 0;
			else if (MFVideoFormat_H264 == subtype)
				m_format = 2;
			else if (MFVideoFormat_H265 == subtype)
				m_format = 3;
			else
				m_format = -1;
			
		}
		
		hr = MFGetAttributeRatio(pGrabberNegotiatedInputMedia, MF_MT_FRAME_RATE, &nNegNumeratorFps, &nNegDenominatorFps);
		if (SUCCEEDED(hr)) {
			//TSK_DEBUG_INFO("MF video producer topology vs sdp parameters: fps(%u/%u)",
			//               TMEDIA_PRODUCER(pSelf)->video.fps, (nNegNumeratorFps / nNegDenominatorFps)
			//              );
			m_fps = (nNegNumeratorFps / nNegDenominatorFps);
		}
		CString str;
		str.Format("mjpeg %d*%d %d@fps", m_width, m_height, m_fps);
		AfxMessageBox(str);
#endif
		//dzlog_debug("Video width: %d, height: %d, fps: %d. self: %08x !!!", TMEDIA_PRODUCER(pSelf)->video.width, TMEDIA_PRODUCER(pSelf)->video.height, TMEDIA_PRODUCER(pSelf)->video.fps, pSelf);

		// Create EVR watcher for the preview.
	//	m_pWatcherPreview = new DisplayWatcher(m_hWndPreview, pEvr, hr);
		//if (m_pWatcherPreview)
			//m_pWatcherPreview->SetMessageParent(m_hMsgParentWnd);
		CHECK_HR(hr);
	}

bail:
	SafeRelease( &pSessionAttributes );
	SafeRelease( &pTopology );
	SafeRelease( &pEvr );
	SafeRelease( &pEncoderInputType );
	SafeRelease( &pNodeGrabber );
	SafeRelease( &pGrabberNegotiatedInputMedia );

	if (SUCCEEDED( hr ))
	{
		//dzlog_debug("plugin_win_mf_producer_video_start(), OK. self: %08x !!!", pSelf);
	}
	else
	{
		//dzlog_error("plugin_win_mf_producer_video_start(), Not OK. self: %08x !!!", pSelf);
	}

	m_bPrepared = SUCCEEDED( hr );
	//return m_bPrepared ? 0 : -1;
	return MFStart();
}

int CMFDevCapture::MFUnInit()
{
	if (m_bStarted) {
		m_format = 0;
		m_fps = 30;
		m_width = 1280;
		m_height = 720;
		// plugin_win_mf_producer_video_stop(TMEDIA_PRODUCER(pSelf));
		MFStop(); 
		//TSK_DEBUG_ERROR("Producer must be stopped before calling unprepare");
	}
	if (m_pDeviceList) {
		delete m_pDeviceList, m_pDeviceList = NULL;
	}
	if (m_pWatcherPreview) {
		m_pWatcherPreview->Stop();
	}
	if (m_pSource) {
		m_pSource->Shutdown();
	}
	if (m_pSession) {
		m_pSession->Shutdown();
	}

//	SafeRelease( &m_pEncoder );
	SafeRelease( &m_pSession );
	SafeRelease( &m_pSource );
	SafeRelease( &m_pSinkActivatePreview );
	SafeRelease( &m_pGrabberCB);
	SafeRelease( &m_pSinkGrabber );
	SafeRelease( &m_pTopology );
	SafeRelease( &m_pGrabberInputType );

	if (m_pWatcherPreview) {
		delete m_pWatcherPreview;
		m_pWatcherPreview = NULL;
	}

	m_bPrepared = false;

	return 0;
}


int CMFDevCapture::MFStart()
{
	if (m_bStarted) {
		//TSK_DEBUG_INFO("MF video producer already started");
		return 0;
	}
	if (!m_bPrepared) {
		//TSK_DEBUG_ERROR("MF video producer not prepared");
		return -1;
	}

	HRESULT hr = S_OK;

	// Run preview watcher
	if (m_pWatcherPreview) {
		CHECK_HR( hr = m_pWatcherPreview->Start() );
	}

	// Run the media session.
	CHECK_HR( hr = MFUtils::RunSession( m_pSession, m_pTopology ) );

	// Start asynchronous watcher thread
	m_bStarted = true;
	int ret = tsk_thread_create( &m_ppTread[0], RunSessionThread, this );
	if (ret != 0) {
		//TSK_DEBUG_ERROR("Failed to create thread");
		hr = E_FAIL;
		m_bStarted = false;
		if (m_ppTread[0]) {
			tsk_thread_join( &m_ppTread[0] );
		}
		MFUtils::ShutdownSession( m_pSession, m_pSource );
		goto bail;
	}

bail:
	return SUCCEEDED( hr ) ? 0 : -1;
}

int CMFDevCapture::MFSetPlayWnd(HWND hPlayWnd )
{
	HRESULT hr = S_OK;
	m_hWndPreview = hPlayWnd;
	if (m_pWatcherPreview) {
		CHECK_HR( hr = m_pWatcherPreview->SetHwnd( hPlayWnd ) );
	}
bail:
	return SUCCEEDED( hr ) ? 0 : -1;
}


int CMFDevCapture::MFStop()
{
	HRESULT hr = S_OK;

	if (m_pWatcherPreview) {
		hr = m_pWatcherPreview->Stop();
	}

	// for the thread
	m_bStarted = false;
	hr = MFUtils::ShutdownSession( m_pSession, NULL ); // stop session to wakeup the asynchronous thread
	if (m_ppTread[0]) {
		tsk_thread_join( &m_ppTread[0] );
	}
	hr = MFUtils::ShutdownSession( NULL, m_pSource ); // stop source to release the camera

	
	return SUCCEEDED( hr ) ? 0 : -1;
}

typedef struct
{
	unsigned int	uiSize;
	unsigned short	uiReserved1;
	unsigned short	uiReserved2;
	unsigned int	uiOffBits;
}My2BITMAPFILEHEADER;

typedef struct
{
	unsigned int	uiSize;
	int				iWidth;
	int				iHeight;
	unsigned short	uiPlanes;
	unsigned short	uiBitCount;
	unsigned int	uiCompression;
	unsigned int	uiSizeImage;
	int				iXPelsPerMeter;
	int				iYPelsPerMeter;
	unsigned int	uiClrUsed;
	unsigned int	biClrImportant;
}My2BITMAPINFOHEADER;

static bool save_rgb32_frame_as_bmp(char *pBuffer, int iWidth, int iHeight, char *pcFileName)
{
	//char pcArray[256];

	if (NULL == pBuffer || 0 == iWidth || 0 == iHeight || NULL == pcFileName)
	{
		//dzlog_error("save_frame_to_bmp(), invalid parameter !!!");
		return false;
	}

	My2BITMAPFILEHEADER bfh = { 0 };
	My2BITMAPINFOHEADER bih = { 0 };

	unsigned short uiType = 0x4d42;

	bfh.uiSize = sizeof(uiType) + sizeof(bfh) + sizeof(bih) + iWidth*iHeight * 4;
	bfh.uiReserved1 = 0;
	bfh.uiReserved2 = 0;
	bfh.uiOffBits = 0x36;

	bih.uiSize = sizeof(My2BITMAPINFOHEADER);
	bih.iWidth = iWidth;
	bih.iHeight = iHeight;
	bih.uiPlanes = 1;
	bih.uiBitCount = 32;
	bih.uiCompression = 0;
	bih.uiSizeImage = 0;
	bih.iXPelsPerMeter = 5000;
	bih.iYPelsPerMeter = 5000;
	bih.uiClrUsed = 0;
	bih.biClrImportant = 0;

	FILE *file = fopen(pcFileName, "wb");
	if (!file)
	{
		//dzlog_error("save_frame_to_bmp(), failed to save frame to %s  !!!", pcFileName);
		return false;
	}



	fwrite(&uiType, sizeof(uiType), 1, file);
	fwrite(&bfh, sizeof(bfh), 1, file);
	fwrite(&bih, sizeof(bih), 1, file);
	fwrite(pBuffer, iWidth*iHeight * 4, 1, file);
	fclose(file);

	return true;
}
int CMFDevCapture::MFSnapshot( char * lpFile )
{
	HRESULT hr = S_OK;
	if (m_pWatcherPreview) {
		BITMAPINFOHEADER bih = { 0 };
		DWORD dwSize = 0;
		BYTE *pFrameData = NULL;
		bih.biSize = sizeof(BITMAPINFOHEADER);

		hr = m_pWatcherPreview->GetSnapshot(&bih, &pFrameData, &dwSize);
		if (SUCCEEDED(hr))
		{
			if (!save_rgb32_frame_as_bmp((char*)pFrameData, bih.biWidth, bih.biHeight, lpFile))
			{
				hr = E_FAIL;
			}
		}

	}
	return SUCCEEDED( hr ) ? 0 : -1;
}

void*  CMFDevCapture::RunSessionThread( void *pArg )
{
	CMFDevCapture *pSelf = (CMFDevCapture *)pArg;
	HRESULT hrStatus = S_OK;
	HRESULT hr = S_OK;
	IMFMediaEvent *pEvent = NULL;
	MediaEventType met;

	//TSK_DEBUG_INFO("RunSessionThread (MF video producer) - ENTER");

	while (pSelf->m_bStarted) {
		hr = pSelf->m_pSession->GetEvent( 0, &pEvent );
		if (hr == MF_E_SHUTDOWN) {
			if (pSelf->m_bStarted) {
				CHECK_HR( hr ); // Shutdown called but "bStarted" not equal to false
			}
			break; // Shutdown called and "bStarted" is equal to false => break the loop
		}
		CHECK_HR( hr = pEvent->GetStatus( &hrStatus ) );
		CHECK_HR( hr = pEvent->GetType( &met ) );

		if (FAILED( hrStatus ) /*&& hrStatus != MF_E_NO_SAMPLE_TIMESTAMP*/) {
			//TSK_DEBUG_ERROR("Session error: 0x%x (event id: %d)\n", hrStatus, met);
			hr = hrStatus;
			goto bail;
		}
		if (met == MESessionEnded) {
			break;
		}
		SafeRelease( &pEvent );
	}

bail:
	//TSK_DEBUG_INFO("RunSessionThread (MF video producer) - EXIT");

	return NULL;
}

void CMFDevCapture::MFSetMsgParent( HWND hParentWnd )
{
	m_hMsgParentWnd = hParentWnd;
	if ( m_pWatcherPreview == NULL ){
		return;
	}
	m_pWatcherPreview->SetMessageParent( m_hMsgParentWnd );
}


int  CMFDevCapture::MFMediaDataCB(LONGLONG llSampleTime, LONGLONG llSampleDuration, const BYTE * pSampleBuffer, DWORD dwSampleSize)
{

	TRACE(" ***  Video frame size = %d\n", dwSampleSize);

	return 0;
}