﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 MFCUsbCamCapture.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MFCUSBCAMCAPTURE_DIALOG     102
#define IDR_MAINFRAME                   128
#define IDD_VIDEOSETTING                134
#define IDI_ICON_CAMERA                 142
#define IDC_BUTTON1                     1000
#define IDC_BTN_CANCEL                  1001
#define IDC_COMBO_SIZE                  1006
#define IDC_BTN_OK                      1007
#define IDC_LIST1                       1012
#define IDC_Version                     1013
#define IDC_GROUP_STATIC                1014
#define IDC_STATIC_BTN                  1015
#define IDC_BTN_OPEN                    1016
#define IDC_BTN_CLOSE                   1017
#define IDC_STATIC_VID                  1018
#define IDC_STATIC_PID                  1019
#define ID_32772                        32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
