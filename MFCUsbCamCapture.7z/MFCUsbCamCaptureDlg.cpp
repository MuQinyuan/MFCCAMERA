﻿
// MFCUsbCamCaptureDlg.cpp: 实现文件
//

#include "stdafx.h"
#include "framework.h"
#include "MFCUsbCamCapture.h"
#include "MFCUsbCamCaptureDlg.h"
#include "afxdialogex.h"
#include"CSettingDlg.h"
#include"dbt.h"
#include <initguid.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
#define MAX_FORMAT_SIZE 48
#include "MultiCamera.h"

enum {
	USERITEM_DEVICE0 = WM_USER + 200,
	USERITEM_DEVICE1,
	USERITEM_DEVICE2,
	USERITEM_DEVICE3,
	USERITEM_DEVICE4,
	USERITEM_DEVICE5,
	USERITEM_DEVICE6,
	USERITEM_DEVICE7,
	USERITEM_DEVICE8,
	USERITEM_DEVICE9
};
enum {
	USERITEM_AUDEVICE0 = WM_USER + 300,
	USERITEM_AUDEVICE1,
	USERITEM_AUDEVICE2,
	USERITEM_AUDEVICE3,
	USERITEM_AUDEVICE4,
	USERITEM_AUDEVICE5,
	USERITEM_AUDEVICE6,
	USERITEM_AUDEVICE7,
	USERITEM_AUDEVICE8,
	USERITEM_AUDEVICE9
};
enum {
	USERITEM_MENU_FILE = WM_USER + 100,
	USERITEM_MENU_DEVICE,
	USERITEM_MENU_AUDEVICE,
	USERITEM_MENU_EDIT,
	USERITEM_MENU_SETTING,
	
};

// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void On32772();
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()




CMFCUsbCamCaptureDlg::~CMFCUsbCamCaptureDlg() {

	if(m_device!=NULL)
	delete m_device;
	for (int i = 0; i < MAX_FORMAT_SIZE; i++)
		delete[] m_uSize[i];
	delete[] m_uSize;
	m_PopupMenu.Detach();
	m_PopupAuMenu.Detach();
	if (m_auDevice != NULL)
		delete m_auDevice;

	
}
CMFCUsbCamCaptureDlg::CMFCUsbCamCaptureDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_MFCUSBCAMCAPTURE_DIALOG, pParent)
{
	
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON_CAMERA);
	m_device = NULL;
	m_auDevice = NULL;
	m_nItemID = 0;
	m_uSize = new int* [MAX_FORMAT_SIZE];
	for (int i = 0; i < MAX_FORMAT_SIZE; i++) {
		m_uSize[i] = new int[4];
		memset(m_uSize[i], 0, sizeof(int));
	}
	
	m_strMsg = NULL;
	m_width=0;
	m_height=0;
	m_fps=0;
	m_format=0;
	m_flags = false;
	m_EventType = 0;
	MyThread = NULL;
}

void CMFCUsbCamCaptureDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CMFCUsbCamCaptureDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &CMFCUsbCamCaptureDlg::OnBnClickedButton1)
	ON_WM_DEVICECHANGE()
	
//	ON_WM_APPCOMMAND()
ON_MESSAGE(WM_SUCESSCLICK, &CMFCUsbCamCaptureDlg::OnSucessClick)
ON_WM_CTLCOLOR()
ON_WM_CREATE()
ON_WM_DESTROY()
END_MESSAGE_MAP()

void CMFCUsbCamCaptureDlg::MoveItem() {
	CRect rect = { 0 };

	CWnd* desktopWnd = GetDesktopWindow();
	desktopWnd->GetWindowRect(&rect);


	MoveWindow(0, 0, rect.Width() / 2, rect.Height() / 2+ rect.Height()/6);


	//CRect rect = { 0 };
	m_statusBar.Create(this);
	UINT uID[] = { 100,101 };
	m_statusBar.SetIndicators(uID, 2);
	m_statusBar.SetPaneInfo(0, 100, SBPS_NORMAL, rect.Width() / 8);
	m_statusBar.SetPaneInfo(1, 101, SBPS_STRETCH, 0);
	//RECT rect = { 0 };
	GetWindowRect(rect);
	CRect sideRect = { 0 };
	
	//CString str;
	//str.Format("%d%d",rect.right,rect.Width());
	//AfxMessageBox(str);
	GetDlgItem(IDC_STATIC)->MoveWindow(rect.Width()/100, 0, rect.Width()- (rect.Width() / 100*4),
	(rect.Width() - (rect.Width() / 100 * 4))/16*9);

	GetClientRect(rect);
	m_statusBar.MoveWindow(0, rect.bottom - rect.bottom/32, rect.right, rect.bottom /32, true);
	GetDlgItem(IDC_GROUP_STATIC)->MoveWindow(rect.right /100, rect.bottom - rect.bottom / 5, rect.right / 2, rect.bottom / 6);
	GetDlgItem(IDC_BUTTON1)->MoveWindow(rect.right/16, rect.bottom - rect.bottom / 8, rect.right / 10, rect.bottom/22);
	GetDlgItem(IDC_Version)->MoveWindow(rect.right / 5, rect.bottom - rect.bottom / 8, rect.right / 4, rect.bottom / 22);
	GetDlgItem(IDC_STATIC_BTN)->MoveWindow(rect.right / 2, rect.bottom - rect.bottom / 5, rect.right / 2- rect.right / 100, rect.bottom / 6);
	GetDlgItem(IDC_BTN_OPEN)->MoveWindow(rect.right / 2+ rect.right / 16, rect.bottom - rect.bottom / 8, rect.right / 10, rect.bottom / 22);
	GetDlgItem(IDC_BTN_CLOSE)->MoveWindow(rect.right / 2 + rect.right / 3, rect.bottom - rect.bottom / 8, rect.right / 10, rect.bottom / 22);
	GetDlgItem(IDC_STATIC_VID)->MoveWindow(rect.right / 5, rect.bottom - rect.bottom / 12, rect.right / 4, rect.bottom / 22);
	GetDlgItem(IDC_STATIC_PID)->MoveWindow(rect.right / 3, rect.bottom - rect.bottom / 12, rect.right / 8, rect.bottom / 22);
}// CMFCUsbCamCaptureDlg 消息处理程序

BOOL CMFCUsbCamCaptureDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标
	
	MoveItem();
	DEV_BROADCAST_DEVICEINTERFACE DevBroadcastDeviceInterface;
	memset(&DevBroadcastDeviceInterface, 0, sizeof(DEV_BROADCAST_DEVICEINTERFACE));
	DevBroadcastDeviceInterface.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
	
	DevBroadcastDeviceInterface.dbcc_classguid = { 0xA5DCBF10, 0x6530, 0x11D2, { 0x90, 0x1F, 0x00, 0xC0, 0x4F, 0xB9, 0x51, 0xED } };
	RegisterDeviceNotification(this->GetSafeHwnd(), &DevBroadcastDeviceInterface, DEVICE_NOTIFY_WINDOW_HANDLE);
	// TODO: 在此添加额外的初始化代码
	
	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

int CMFCUsbCamCaptureDlg::CreateAuDevMenu() {
	HRESULT hr = S_OK;
	WCHAR* auDevNum;
	CString str_auDevNum;
	int audioDevNum = 0;

#if 0
	IMFAttributes* pConfig = NULL;
	IMFActivate** ppDevices = NULL;
	UINT32 count = 0;
	LPWSTR ppszName;
	hr = MFCreateAttributes(&pConfig, 1);
	if (SUCCEEDED(hr))
	{
		hr = pConfig->SetGUID(
			MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE,
			MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_AUDCAP_GUID
		);
	}
	
	if (SUCCEEDED(hr))
	{
		hr = MFEnumDeviceSources(pConfig, &ppDevices, &count);
	}
	pConfig->Release();
	pConfig = NULL;
	for (int i = 0; i < count; i++) {
	
		ppDevices[i]->GetAllocatedString(MF_DEVSOURCE_ATTRIBUTE_FRIENDLY_NAME,
			&ppszName,NULL);
		str_auDevNum = ppszName;
		m_PopupAuMenu.AppendMenuA(MF_STRING, (UINT_PTR)USERITEM_AUDEVICE0 + i, str_auDevNum);
	}
	return TRUE;
#endif
#if 1
	if (!m_auDevice && !(m_auDevice = new DeviceListAudio())) {
		//dzlog_error("plugin_win_mf_producer_video_prepare(), Failed to create device list. self: %08x !!!", pSelf);
		hr = E_OUTOFMEMORY;
		return FALSE;
	}
	hr = m_auDevice->EnumerateDevices();
	if (!SUCCEEDED(hr)) {
		//dzlog_error("plugin_win_mf_producer_video_prepare(), Failed to enumerate devices. self: %08x !!!", pSelf);
		return FALSE;
	}
	if ((audioDevNum=m_auDevice->Count()) == 0) {
		
		AfxMessageBox(_T("没找到设备!"));
		return FALSE;
	}
	for (int i = 0; i < audioDevNum; i++) {
	
		m_auDevice->GetDeviceName(i,&auDevNum);
		str_auDevNum = auDevNum;
		m_PopupAuMenu.AppendMenuA(MF_STRING, (UINT_PTR)USERITEM_AUDEVICE0 + i, str_auDevNum);
	}
	return TRUE;
#endif
}
void CMFCUsbCamCaptureDlg::DlgInit() 
{

	
	CMenu m_MainMenu;
	
	m_MainMenu.CreateMenu();
	m_MainMenu.AppendMenuA(MF_STRING, (UINT_PTR)USERITEM_MENU_FILE, _T("文件"));
	
	m_PopupMenu.CreatePopupMenu();
	m_PopupAuMenu.CreatePopupMenu();
	
	CreateDevMenu(this);
	CreateAuDevMenu();
	m_MainMenu.InsertMenuA((UINT)USERITEM_DEVICE0, MF_POPUP | MF_BYCOMMAND | MF_CHECKED | MF_STRING, (UINT_PTR)m_PopupMenu.m_hMenu, _T("视频设备"));
	m_MainMenu.InsertMenuA((UINT)USERITEM_MENU_AUDEVICE, MF_POPUP | MF_BYCOMMAND | MF_CHECKED | MF_STRING, (UINT_PTR)m_PopupAuMenu.m_hMenu, _T("音频设备"));
		m_MainMenu.AppendMenuA(MF_STRING, (UINT_PTR)USERITEM_MENU_EDIT, "选项");
		m_MainMenu.AppendMenuA(MF_STRING, (UINT_PTR)USERITEM_MENU_SETTING, "设置");
		SetMenu(&m_MainMenu);

		m_MainMenu.Detach();


}

void CMFCUsbCamCaptureDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CMFCUsbCamCaptureDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
	
	DlgInit();
	
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CMFCUsbCamCaptureDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

BOOL CMFCUsbCamCaptureDlg::GetSonixCamVersion(CString& strVersion) {


	//CameraInfo* m_ci=new CameraInfo[10];
	CameraInfo m_ci[10];
	LONG devNum = 0;
	if (NOERROR == SonixCam_EnumDevice(m_ci, &devNum, 10)&&devNum!=0) 
	{
		for (int i = 0; i < devNum; i++) 
		{
		
			if (NOERROR == SonixCam_SelectDevice(i)) 
			{
				
				
					unsigned char pData[128] = {0};
					if (NOERROR == SonixCam_GetFwVersion(pData, 128))
					{
						strVersion = pData;
					
						return TRUE;
						
					}
					else
					{
					
						return FALSE;
					}

				
			
			}
			else
			{
			
				return FALSE;
			}
		}
	}
	else
	{
	
		return FALSE;
	}
	
	//delete m_ci;
//#endif

	return TRUE;
}
BOOL CMFCUsbCamCaptureDlg::GetUsbCamVersionXU(CString& strVersion,int vid,UsbGuid &xuGUID,unsigned char cs) 
{
	InitUsbCamLib();
	CamDevInfo cam[MAX_CAM_NUM];
	UsbCamHandler Usbhandle = NULL;
	int hasFindDevNum = 0;
	int hr = 0;
	hr == GetCurCamDevs(&cam, &hasFindDevNum);
	if (hr != USB_CAM_LIB_SUCCESS || hasFindDevNum == 0)
	{
		AfxMessageBox("1");
		UnInitUsbCamLib();
		return FALSE;
	}
	int index = -1;
	for (int i = 0; i < hasFindDevNum; i++)
	{
		//这里只用vid判断
		if (cam[i].vid == vid)
		{
			index = i;
			break;
		}
	}
	if (index == -1)
	{
		UnInitUsbCamLib();
		return FALSE;
	}
	hr == OpenUsbCamDev(&cam[index], &Usbhandle);
	if (hr != USB_CAM_LIB_SUCCESS)
	{
		AfxMessageBox("2");
		CloseUsbCamDev(Usbhandle);
		UnInitUsbCamLib();
		return FALSE;
	} 
	ExUnitInfo xuInfo[MAX_EX_UNIT_NUM];
	int xuNum;
	
	hr == GetExUnitInfo(Usbhandle, &xuInfo, &xuNum);
	if (hr != USB_CAM_LIB_SUCCESS)
	{
		AfxMessageBox("3");
		CloseUsbCamDev(Usbhandle);
		UnInitUsbCamLib();
		return FALSE;
	}
	memcpy(&xuInfo[0].guid, &xuGUID, sizeof(UsbGuid));
	unsigned char buf[1024] = { 0 };
	if(vid==0x2207)
	{
		int cmdLen = GetCtrlCmdLen(Usbhandle, &xuInfo[0], cs);
		if (cmdLen < 0)
		{
			AfxMessageBox("4");
			CloseUsbCamDev(Usbhandle);
			UnInitUsbCamLib();
			return FALSE;
		}
		ExCtrlCmd euCmd;
		euCmd.CtrlID = 0x02;
		switch (cmdLen)
		{
		case 4:
			euCmd.CtrlID = 0x04;
			break;
		default:
			euCmd.CtrlID = 0x02;
			break;
		}
	
		euCmd.data = buf;
		euCmd.KsNodeID = xuInfo[0].KsNodeID;
		euCmd.len = 60;
		euCmd.query = QUERY_GET;
		memcpy(&euCmd.guid, &xuGUID, sizeof(UsbGuid));
		hr = UvcXuCommand(Usbhandle, &euCmd);
		if (hr != USB_CAM_LIB_SUCCESS)
		{
			AfxMessageBox("5");
			CloseUsbCamDev(Usbhandle);
			UnInitUsbCamLib();
			return FALSE;
		}

		strVersion.Format("%s", buf);
	}
	else if (vid == 0xeba4) 
	{
		int cmdLen = GetCtrlCmdLen(Usbhandle, &xuInfo[0], cs);
		if (cmdLen < 0)
		{
			
			AfxMessageBox("4");
			CloseUsbCamDev(Usbhandle);
			UnInitUsbCamLib();
			return FALSE;
		}
		buf[0] = 0xFE; buf[1] = 0x07;
		ExCtrlCmd euCmd;
		euCmd.CtrlID = cs;
		euCmd.data = buf;
		euCmd.KsNodeID = xuInfo[0].KsNodeID;
		euCmd.len = cmdLen;
		euCmd.query = QUERY_GET;
		memcpy(&euCmd.guid, &xuGUID, sizeof(UsbGuid));
		hr = UvcXuCommand(Usbhandle, &euCmd);

		if (hr != USB_CAM_LIB_OK)
		{
			AfxMessageBox("5");
			CloseUsbCamDev(Usbhandle);
			UnInitUsbCamLib();
			return FALSE;
		}
		euCmd.query = QUERY_GET;
		hr = UvcXuCommand(Usbhandle, &euCmd);
		if (hr != USB_CAM_LIB_OK)
		{
			AfxMessageBox("6");
			CloseUsbCamDev(Usbhandle);
			UnInitUsbCamLib();
			return FALSE;
		}
		int buff = buf[0] | buf[1] << 8;
		char buff2[20] = {0};
		sprintf(buff2, "%x", buff);
		strVersion.Format("V%c.%c.%c",buff2[0],buff2[1],buff2[2]);
		
	}
	CloseUsbCamDev(Usbhandle);
	UnInitUsbCamLib();
	return TRUE;
}

vector<CString> SplitCString2(CString strSource)
{
	vector <CString> vecString;

	int iPos = 0, iPos2 = 0, iPos3 = 0;

	CString strTmp, strTmp1, strTmp2;
	strTmp = strSource.Tokenize("#", iPos);//视频格式
	//strTmp.Format("%d", iPos);
	//AfxMessageBox(strTmp);

	strTmp = strSource.Tokenize("#", iPos);//分辨率
	
	if (strTmp.Trim() != _T(""))
	{
		
		strTmp1 = strTmp.Tokenize("&", iPos2);//width
		vecString.push_back(strTmp1);

		strTmp1 = strTmp.Tokenize("&", iPos2);//height
		vecString.push_back(strTmp1);
	
	}
	
	return vecString;
}

void CMFCUsbCamCaptureDlg::OnBnClickedButton1()
{
	
	//RGB m_rgb(0,0,0);
	if (m_CapPreview.m_bStarted)
	{
		CString strVersion,strPID,strVID;
		WCHAR* productID=NULL;
		HRESULT hr=m_device->GetDeviceProductID(m_nItemID-USERITEM_DEVICE0,&productID);
		if (FAILED(hr)) {
		
			AfxMessageBox("获取版本失败");
			return;
		}
		strVersion = productID;
		vector<CString> count= SplitCString2(strVersion);
		if (count.size() < 2) 
		{
		
			AfxMessageBox("获取版本失败");
			return;
			
		}
		SetDlgItemTextA(IDC_STATIC_VID, "VID:"+count[0].Mid(4));
		SetDlgItemTextA(IDC_STATIC_PID, "PID:"+count[1].Mid(4));
		if (!strcmp(count[0].GetString(), "vid_0c45")) 
		{
			HRESULT hr=SonixCam_Init();
			if (SUCCEEDED(hr)) {
				GetSonixCamVersion(strVersion) ? SetDlgItemTextA(IDC_Version, strVersion) : SetDlgItemTextA(IDC_Version, _T("Sonix getVersion Falied"));
				SonixCam_UnInit();
			}
		}
		else if (!strcmp(count[0].GetString(), "vid_2207") && !strcmp(count[1].GetString(), "pid_0016"))
		{
			UsbGuid xuGUID = { 0x41769EA2, 0x04DE, 0xE347,{ 0x8B, 0x2B, 0xF4, 0x34, 0x1A, 0xFF, 0x00, 0x3B} };
			GetUsbCamVersionXU(strVersion, 0x2207, xuGUID, 0x02)?SetDlgItemTextA(IDC_Version,strVersion): SetDlgItemTextA(IDC_Version, _T("RK getVersion Falied"));
		}
		else if (!strcmp(count[0].GetString(), "vid_eba4") && !strcmp(count[1].GetString(), "pid_1303"))
		{			
			UsbGuid xuGUID = { 0x46394292, 0x0CD0, 0x4AE3,{ 0x87, 0x83, 0x31, 0x33, 0xF9, 0xEA, 0xAA, 0x3B} };
			GetUsbCamVersionXU(strVersion, 0xeba4, xuGUID, 0x09) ? SetDlgItemTextA(IDC_Version, strVersion) : SetDlgItemTextA(IDC_Version, _T("RK getVersion Falied"));
		}
		else
		{
			SetDlgItemTextA(IDC_Version, _T("Other Camera"));
		}
		

	}
	else
	{
		SetDlgItemTextA(IDC_Version, _T("Falied"));
	}
	
}

bool CMFCUsbCamCaptureDlg::GetDeviceCount(int* deviceNum) {

	HRESULT hr = S_OK;
	if (!m_device && !(m_device = new DeviceListVideo())) {
		//dzlog_error("plugin_win_mf_producer_video_prepare(), Failed to create device list. self: %08x !!!", pSelf);
		hr = E_OUTOFMEMORY;
		return FALSE;
	}
	// enumerate devices
	hr = m_device->EnumerateDevices();
	if (!SUCCEEDED(hr)) {
		//dzlog_error("plugin_win_mf_producer_video_prepare(), Failed to enumerate devices. self: %08x !!!", pSelf);
		return FALSE;
	}
	if ((*deviceNum = m_device->Count()) == 0) {
		AfxMessageBox(_T("没找到设备!"));
		return FALSE;
	}

	return TRUE;
}
BOOL CMFCUsbCamCaptureDlg::BarToolFormat(CString& str){
	switch (m_CapPreview.m_format)
	{
	case 0:
		str.Format("mjpeg %d*%d %d@fps", m_CapPreview.m_width, m_CapPreview.m_height, m_CapPreview.m_fps);
		break;
	case 1:
		str.Format("yuv %d*%d %d@fps", m_CapPreview.m_width, m_CapPreview.m_height, m_CapPreview.m_fps);
		break;
	case 2:
		str.Format("h264 %d*%d %d@fps", m_CapPreview.m_width, m_CapPreview.m_height, m_CapPreview.m_fps);
		break;
	case 3:
		str.Format("h265 %d*%d %d@fps", m_CapPreview.m_width, m_CapPreview.m_height, m_CapPreview.m_fps);
		break;
	default:
		str.Format("faild %d*%d %d@fps", m_CapPreview.m_width, m_CapPreview.m_height, m_CapPreview.m_fps);
		break;
	}

	return 0;
}
BOOL CMFCUsbCamCaptureDlg::OnCommand(WPARAM  wParam, LPARAM  lParam) {
	UINT32 width, height;
	CString str;
	int nItemID = LOWORD(wParam);
	m_flags = false;
	//vector<vector<UINT32>>uSize;
	//uSize.push_back(vector<UINT32>{});
	if (nItemID >= USERITEM_DEVICE0 && nItemID <= USERITEM_DEVICE9)
	{
#if 1
		//m_PopupMenu.DeleteMenu(nItemID, MF_BYCOMMAND);
		m_device->GetDeviceFormat(nItemID - USERITEM_DEVICE0, &width, &height, m_uSize);

		CSettingDlg m_Setting(NULL, m_uSize,m_width,m_height,m_fps,m_format);

		if(m_Setting.DoModal()== IDOK)
		{
			CheckMenuItem(GetSubMenu(GetMenu()->GetSafeHmenu(), 1), nItemID - USERITEM_DEVICE0, MF_CHECKED | MF_BYPOSITION);//设置✔标志位
			if (nItemID != m_nItemID) 
			{
				SetDlgItemTextA(IDC_Version, "");
				SetDlgItemTextA(IDC_STATIC_VID, "VID:");
				SetDlgItemTextA(IDC_STATIC_PID, "PID:");
				CheckMenuItem(GetSubMenu(GetMenu()->GetSafeHmenu(), 1), m_nItemID - USERITEM_DEVICE0, MF_UNCHECKED | MF_BYPOSITION);
			}
			if (m_CapPreview.m_bStarted)
				m_CapPreview.MFUnInit();
		
			m_nItemID = nItemID;
			nItemID = nItemID - USERITEM_DEVICE0;
			if(m_flags)
				m_CapPreview.MFInit(nItemID, GetDlgItem(IDC_STATIC)->m_hWnd,m_width,m_height,m_fps,m_format);
			else
				m_CapPreview.MFInit(nItemID, GetDlgItem(IDC_STATIC)->m_hWnd);

			BarToolFormat(str);
			//AfxMessageBox(str);
			if (m_CapPreview.m_bStarted)
				m_statusBar.SetPaneText(0,str);
			if(GetDlgItem(IDC_BTN_OPEN)->IsWindowEnabled())
				GetDlgItem(IDC_BTN_OPEN)->EnableWindow(0);
		}
#endif

		for (int i = 0; i < MAX_FORMAT_SIZE; i++) 
		{
			memset(m_uSize[i], 0, sizeof(int));
		}
		
		
		//bad:
		//m_nItemID = nItemID;
	}
	else if (nItemID == IDC_BTN_OPEN) 
	{
	
		if (m_CapPreview.m_bStarted) 
		{
			m_CapPreview.MFUnInit();
			CheckMenuItem(GetSubMenu(GetMenu()->GetSafeHmenu(), 1), m_nItemID - USERITEM_DEVICE0, MF_UNCHECKED | MF_BYPOSITION);
		}

		m_nItemID = USERITEM_DEVICE0;
		CheckMenuItem(GetSubMenu(GetMenu()->GetSafeHmenu(), 1), m_nItemID-USERITEM_DEVICE0, MF_CHECKED | MF_BYPOSITION);
		m_CapPreview.MFInit(0, GetDlgItem(IDC_STATIC)->m_hWnd);
		m_height=m_CapPreview.m_height;
		m_width=m_CapPreview.m_width;
		m_fps=m_CapPreview.m_fps;
		m_format=m_CapPreview.m_format;
		BarToolFormat(str);
		m_statusBar.SetPaneText(0, str);
		GetDlgItem(IDC_BTN_OPEN)->EnableWindow(0);
		
	}
	else if (nItemID == IDC_BTN_CLOSE) 
	{
		int uPixel;
		if (m_CapPreview.m_bStarted) 
		{
			m_CapPreview.MFUnInit();
			CheckMenuItem(GetSubMenu(GetMenu()->GetSafeHmenu(), 1), m_nItemID - USERITEM_DEVICE0, MF_UNCHECKED | MF_BYPOSITION);
			GetDlgItem(IDC_BTN_OPEN)->EnableWindow(1);
			m_statusBar.SetPaneText(0, "");
			CRect rect = { 0 };
			GetDlgItem(IDC_STATIC)->GetClientRect(&rect);
			FillRect(GetDlgItem(IDC_STATIC)->GetDC()->GetSafeHdc(), &rect, CBrush(RGB(0, 0, 0)));
		}
	}
	if (nItemID == USERITEM_AUDEVICE0) {

		;
		//m_CapPreview.AudioInit(0);

	}
	return CDialog::OnCommand(wParam, lParam);
}

vector<CString> SplitCString(CString strSource)
{
	vector <CString> vecString;
	int iPos = 0, iPos2 = 0, iPos3 = 0;

	CString strTmp, strTmp1, strTmp2;
	strTmp = strSource.Tokenize(" ", iPos);//视频格式
	//strTmp.Format("%d", iPos);
	//AfxMessageBox(strTmp);
	vecString.push_back(strTmp);

	strTmp = strSource.Tokenize(" ", iPos);//分辨率

	if (strTmp.Trim() != _T(""))
	{
		strTmp1 = strTmp.Tokenize("*", iPos2);//width
		vecString.push_back(strTmp1);

		strTmp1 = strTmp.Tokenize("*", iPos2);//height
		vecString.push_back(strTmp1);

		strTmp = strSource.Tokenize(" ", iPos);//帧率
		strTmp2 = strTmp.Tokenize("@", iPos3);
		vecString.push_back(strTmp2);

	}

	return vecString;
}
 LRESULT CMFCUsbCamCaptureDlg::OnSucessClick(WPARAM wParam, LPARAM lParam)
{
	m_strMsg = (CString*)wParam;
	CString str;
	vector<CString>m_strArray;

	m_strArray=SplitCString(*m_strMsg);

	str = m_strArray[0].GetString();

	m_flags = true;

	if (str == "mjpeg")

		m_format = 0;

	else if (str == "yuv")

		m_format = 1;

	else if (str == "h264")

		m_format = 2;

	else if (str == "h265")


		m_format = 3;

	m_width = atoi(m_strArray[1].GetString());

	m_height = atoi(m_strArray[2].GetString());

	m_fps = atoi(m_strArray[3].GetString());
	
	return 0;
}

 UINT CMFCUsbCamCaptureDlg::MyThreadFunction(void*  pParam) 
 {
	 int devCount=0;
	 CString strDevName;
	 CString itemName;
	 WCHAR* devName;
	 bool bflags = false;
	 CMFCUsbCamCaptureDlg* m_dlg = (CMFCUsbCamCaptureDlg*)pParam;
	 Sleep(1000);
	 CreateDevMenu(m_dlg);
	 return 0;
 }

 BOOL CMFCUsbCamCaptureDlg::OnDeviceChange(UINT nEventType, DWORD dwData) 
 {
	 CString str;
	 int num;
	
	 if (nEventType == DBT_DEVICEARRIVAL || nEventType == DBT_DEVICEREMOVECOMPLETE)
	 {
		 m_EventType = nEventType;
		 MyThread = AfxBeginThread(MyThreadFunction, this);
	 }

	 return  TRUE;
	 
}

 HBRUSH CMFCUsbCamCaptureDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
 {
	 HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);


	 if (pWnd->GetDlgCtrlID() == IDC_Version) {
		 pDC->SetBkMode(TRANSPARENT);
		 pDC->SetTextColor(RGB(255, 0, 0));
	 }
	 

	 // TODO:  在此更改 DC 的任何特性

	 // TODO:  如果默认的不是所需画笔，则返回另一个画笔
	 return hbr;
 }

 int CMFCUsbCamCaptureDlg::CreateDevMenu(CMFCUsbCamCaptureDlg* m_dlg){
	 CString strDevName; 
	 WCHAR* devName;
	 int devNumber;
	 
	
	 int count = m_dlg->m_PopupMenu.GetMenuItemCount();
	 

		 for (int i = 0; i < count; i++)
			 m_dlg->m_PopupMenu.DeleteMenu(USERITEM_DEVICE0 + i, MF_BYCOMMAND);

		 if (m_dlg->GetDeviceCount(&devNumber))
		 {
			 if (m_dlg->m_device == NULL || devNumber == 0)
			 {
				 AfxMessageBox(_T("获取摄像头失败"));
				 //return;
			 }

			 for (int i = 0; i < devNumber; i++)
			 {
				 m_dlg->m_device->GetDeviceName(i, &devName);

				 strDevName = devName;
				 if ((USERITEM_DEVICE0 + i) == m_dlg->m_PopupMenu.GetMenuItemID(i))//避免插入相同item
					 break;
				 m_dlg->m_PopupMenu.AppendMenuA(MF_STRING, (UINT_PTR)USERITEM_DEVICE0 + i, strDevName);
				 
			 }

		 }

	 return 0;
 }

 int CMFCUsbCamCaptureDlg::OnCreate(LPCREATESTRUCT lpCreateStruct)
 {
	 if (CDialogEx::OnCreate(lpCreateStruct) == -1)
		 return -1;

	 ::SetPropW(m_hWnd, (LPWSTR)AfxGetApp()->m_pszExeName, (HANDLE)1);
	 // TODO:  在此添加您专用的创建代码
	
	 return 0;
 }


 void CMFCUsbCamCaptureDlg::OnDestroy()
 {
	 CDialogEx::OnDestroy();
	 ::RemovePropW(m_hWnd, (LPWSTR)AfxGetApp()->m_pszExeName);
	 // TODO: 在此处添加消息处理程序代码
 }

