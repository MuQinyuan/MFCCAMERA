/* 
*/
#ifndef PLUGIN_WIN_MF_DEVICES_H
#define PLUGIN_WIN_MF_DEVICES_H

#include "../plugin_win_mf_config.h"

#include <new>
#include <mfapi.h>
#include <mfidl.h>
#include <Mferror.h>
#include <shlwapi.h>
#include "mfreadwrite.h"
//
//  DeviceList [Declaration]
//
class DeviceList
{
    UINT32      m_cDevices;
    IMFActivate **m_ppDevices;

public:
    DeviceList();
    virtual  ~DeviceList();

    UINT32  Count()const;
    void Clear();
    HRESULT GetDeviceAtIndex(UINT32 index, IMFActivate **ppActivate);
    HRESULT GetDeviceBest(IMFActivate **ppActivate, WCHAR *pszName = NULL);
    HRESULT GetDeviceName(UINT32 index, WCHAR **ppszName);
	HRESULT GetDeviceAt(IMFActivate** ppActivate,int index);
	HRESULT GetDeviceGUID(UINT32 index, WCHAR **ppszGUID);
    HRESULT GetDeviceProductID(UINT32 index, WCHAR** ppDeviceID);
    HRESULT GetDeviceFormat(int iDeviceIndex, UINT32* width, UINT32* height, int** uSize);
    HRESULT GetDeviceSize(UINT32 index, WCHAR** ppszGUID);

protected:
    HRESULT EnumerateDevices(const GUID& sourceType);
};

class DeviceListAudio : public DeviceList
{
public:
    HRESULT EnumerateDevices();
};

class DeviceListVideo : public DeviceList
{
public:
    HRESULT EnumerateDevices();
};

#endif /* PLUGIN_WIN_MF_DEVICES_H */
