/* 
*/
#ifndef PLUGIN_WIN_MF_SAMPLE_GRABBER_H
#define PLUGIN_WIN_MF_SAMPLE_GRABBER_H

#include "../plugin_win_mf_config.h"

#include <new>
#include <mfapi.h>
#include <mfidl.h>
#include <Mferror.h>
#include <shlwapi.h>


#define HEART_BEAT_INTERVAL 1000 // 10 seconds


class IMFMediaDataPro
{
public:
	virtual ~IMFMediaDataPro() = 0 {};
	virtual int   MFMediaDataCB(LONGLONG llSampleTime, LONGLONG llSampleDuration, const BYTE * pSampleBuffer, DWORD dwSampleSize) = 0;
};
//
//      Sample Grabber callback [Declaration]
//      http://msdn.microsoft.com/en-us/library/windows/desktop/hh184779(v=vs.85).aspx
//
class SampleGrabberCB : public IMFSampleGrabberSinkCallback
{

    long m_cRef;
	IMFMediaDataPro * m_pWrappedProducer;
	DWORD m_dwStartTime;
	bool m_bStarted;

	SampleGrabberCB(IMFMediaDataPro * pcWrappedProducer) : m_cRef(1), m_pWrappedProducer(pcWrappedProducer)
	{
		m_dwStartTime = GetTickCount();
		m_bStarted = false;
	}

public:
	static HRESULT CreateInstance( IMFMediaDataPro* pcWrappedProducer, SampleGrabberCB **ppCB);


    // IUnknown methods
    STDMETHODIMP QueryInterface(REFIID iid, void** ppv);
    STDMETHODIMP_(ULONG) AddRef();
    STDMETHODIMP_(ULONG) Release();

    // IMFClockStateSink methods
    STDMETHODIMP OnClockStart(MFTIME hnsSystemTime, LONGLONG llClockStartOffset);
    STDMETHODIMP OnClockStop(MFTIME hnsSystemTime);
    STDMETHODIMP OnClockPause(MFTIME hnsSystemTime);
    STDMETHODIMP OnClockRestart(MFTIME hnsSystemTime);
    STDMETHODIMP OnClockSetRate(MFTIME hnsSystemTime, float flRate);

    // IMFSampleGrabberSinkCallback methods
    STDMETHODIMP OnSetPresentationClock(IMFPresentationClock* pClock);
    STDMETHODIMP OnProcessSample(REFGUID guidMajorMediaType, DWORD dwSampleFlags,
                                 LONGLONG llSampleTime, LONGLONG llSampleDuration, const BYTE * pSampleBuffer,
                                 DWORD dwSampleSize);
    STDMETHODIMP OnShutdown();
};


#endif /* PLUGIN_WIN_MF_SAMPLE_GRABBER_H */
