
#include "stdafx.h"
#include "tsk_thread.h"
int tsk_thread_create( void** handle, void *(__cdecl *start) (void *), void *arg )
{
	*((HANDLE*)handle) = CreateThread( NULL, 0, (LPTHREAD_START_ROUTINE)start, arg, 0, NULL );
	return *((HANDLE*)handle) ? 0 : -1;
}
int tsk_thread_destroy( void** handle )
{
	if (handle && *handle) {
		CloseHandle( *((HANDLE*)handle) );
		*handle = NULL;
	}
	return 0;
}
int tsk_thread_join( void ** handle )
{
	int ret;

	if (!handle) {
		TSK_DEBUG_ERROR( "Invalid parameter" );
		return -1;
	}
	if (!*handle) {
		TSK_DEBUG_WARN( "Cannot join NULL handle" );
		return 0;
	}
	ret = (WaitForSingleObject( *((HANDLE*)handle), INFINITE ) == WAIT_FAILED) ? -1 : 0;
	if (ret == 0) {
		ret = tsk_thread_destroy( handle );
	}


	return ret;
}

