/* 
*/
#include "stdafx.h"
#include "mf_devices.h"
#include "mf_utils.h"
#include "Vidcap.h"
DeviceList::DeviceList()
    : m_ppDevices(NULL)
    , m_cDevices(0)
{

}

DeviceList::~DeviceList()
{
    Clear();
}

UINT32 DeviceList::Count()const
{
    return m_cDevices;
}

void DeviceList::Clear()
{
    for (UINT32 i = 0; i < m_cDevices; i++) {
        SafeRelease(&m_ppDevices[i]);
    }
    CoTaskMemFree(m_ppDevices);
    m_ppDevices = NULL;

    m_cDevices = 0;
}

HRESULT DeviceList::EnumerateDevices(const GUID& sourceType)
{
    HRESULT hr = S_OK;
    IMFAttributes *pAttributes = NULL;

    Clear();

    // Initialize an attribute store. We will use this to
    // specify the enumeration parameters.

    hr = MFCreateAttributes(&pAttributes, 1);
   
    // Ask for source type = video capture devices
    if (SUCCEEDED(hr)) {
        hr = pAttributes->SetGUID(
                 MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE,
                 sourceType
             );
    }
   

    // Enumerate devices.
    if (SUCCEEDED(hr)) {
        hr = MFEnumDeviceSources(pAttributes, &m_ppDevices, &m_cDevices);//&m_ppDevices�豸�����豸����
    }
    SafeRelease(&pAttributes);

    return hr;
}

HRESULT DeviceList::GetDeviceAtIndex(UINT32 index, IMFActivate **ppActivate)
{
    if (index >= Count()) {
        return E_INVALIDARG;
    }

    *ppActivate = m_ppDevices[index];
    (*ppActivate)->AddRef();

    return S_OK;
}

HRESULT DeviceList::GetDeviceBest(IMFActivate **ppActivate, WCHAR *pszName /*= NULL*/)
{
    UINT32 index = 0;
    if(pszName) {
        WCHAR *_pszName = NULL;
        BOOL bFound = FALSE;
        for(UINT32 i = 0; i < Count() && !bFound; ++i) {
            if((SUCCEEDED(GetDeviceName(i, &_pszName)))) {
                if(wcscmp(_pszName, pszName) == 0) {
                    index = i;
                    bFound = TRUE;
                    // do not break the loop because we need to free(_pszName)
                }
            }
            if(_pszName) {
                CoTaskMemFree(_pszName), _pszName = NULL;
            }
        }
    }
    return GetDeviceAtIndex(index, ppActivate);
}

// The caller must free the memory for the string by calling CoTaskMemFree
HRESULT DeviceList::GetDeviceName(UINT32 index, WCHAR **ppszName)
{
    if (index >= Count()) {
        return E_INVALIDARG;
    }

    HRESULT hr = S_OK;

    hr = m_ppDevices[index]->GetAllocatedString(
             MF_DEVSOURCE_ATTRIBUTE_FRIENDLY_NAME,
             ppszName,
             NULL
         );

    return hr;
}

HRESULT DeviceList::GetDeviceAt(IMFActivate **ppActivate, int iDeviceIndex)
{
	return GetDeviceAtIndex(iDeviceIndex, ppActivate);
}

HRESULT DeviceListAudio::EnumerateDevices()
{
    // call base class function
    return DeviceList::EnumerateDevices(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_AUDCAP_GUID);
}

HRESULT DeviceListVideo::EnumerateDevices()
{
    // call base class function
    return DeviceList::EnumerateDevices(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID);
}

HRESULT DeviceList::GetDeviceGUID(UINT32 index, WCHAR **ppszGUID)
{
	if (index >= Count()) {
		return E_INVALIDARG;
	}

	HRESULT hr = S_OK;

	hr = m_ppDevices[index]->GetAllocatedString(
		MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK,
		ppszGUID,
		NULL
	);

	return hr;
}
HRESULT DeviceList::GetDeviceProductID(UINT32 index, WCHAR** ppDeviceID)
{
    if (index >= Count()) {
        return E_INVALIDARG;
    }

    HRESULT hr = S_OK;

    hr = m_ppDevices[index]->GetAllocatedString(
        MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK,
        ppDeviceID,
        NULL
    );

    return hr;
}

HRESULT DeviceList::GetDeviceFormat(int iDeviceIndex,UINT32* width,UINT32* height, int** uSize) {
    
    IMFMediaSource* source = NULL;
    HRESULT hr = S_OK;
    IMFMediaType* mediaType = NULL;
    IMFSourceReader* reader = NULL;
    IMFPresentationDescriptor* pPD = NULL;
    IMFStreamDescriptor* pSD = NULL;
    IMFMediaTypeHandler* pHandler = NULL;
    IMFMediaType* pType = NULL;
    DWORD cStreams = 0;
    GUID   subtype,copy_subtype;
    CString str;
    DWORD cTypes = 0;
    WCHAR *buf[1024];
    int uwitdh = 0, uheight = 0, uNum = 0;
    UINT32 pNumRator=0, pDumRator=0;
    CHECK_HR(hr = MFCreateDeviceSource(m_ppDevices[iDeviceIndex], &source));
    CHECK_HR(hr = source->CreatePresentationDescriptor(&pPD)); //����Դ����������
    CHECK_HR(hr = pPD->GetStreamDescriptorCount(&cStreams)); //�õ�Դ��������Ŀ

    for (DWORD i = 0; i < cStreams; i++) {
        BOOL fSelected = FALSE;
        GUID majorType;
        
        CHECK_HR(hr = pPD->GetStreamDescriptorByIndex(i, &fSelected, &pSD));//�õ�ָ������������������Ϣָ��
        CHECK_HR(hr = pSD->GetMediaTypeHandler(&pHandler)); //�õ��������ʹ�����
        
        hr = pHandler->GetMediaTypeCount(&cTypes);//��ȡ�������͵�����
        for (DWORD i = 0; i < cTypes; i++)
        {
            
            CHECK_HR(hr = pHandler->GetMediaTypeByIndex(i, &pType));//��ȡ��������
            CHECK_HR(hr = pType->GetGUID(MF_MT_SUBTYPE, &subtype));
            if (MFVideoFormat_MJPG == subtype|| MFVideoFormat_YUY2 == subtype 
                || MFVideoFormat_H264 == subtype|| MFVideoFormat_H265 == subtype)
            {
                CHECK_HR(hr = MFGetAttributeSize(pType, MF_MT_FRAME_SIZE, width, height));//��ȡ�ֱ���
                CHECK_HR(hr = MFGetAttributeRatio(pType, MF_MT_FRAME_RATE, &pNumRator, &pDumRator));//��ȡ�ֱ���
                if (uwitdh == *width && uheight == *height) {
                    continue;
                }
                else
                {
                    if (uNum <= 48)
                    {
                        CString str;
                        uwitdh = *width;
                        uheight = *height;
                        uSize[uNum][0] = uwitdh;
                        uSize[uNum][1] = uheight;
                        uSize[uNum][3] = pNumRator;
                        if (MFVideoFormat_YUY2 == subtype)
                            uSize[uNum][2] = 1;
                        else if (MFVideoFormat_MJPG == subtype)
                            uSize[uNum][2] = 0;
                        else if (MFVideoFormat_H264 == subtype)
                            uSize[uNum][2] = 2;
                        else if (MFVideoFormat_H265 == subtype)
                            uSize[uNum][2] = 3;
                        else
                            continue;
                      //  str.Format("id:%d %d*%d*@%dfps,%d", uSize[uNum][2], uSize[uNum][0], uSize[uNum][1], uSize[uNum][3], subtype.Data1);
                       // AfxMessageBox(str);
                    }

                    uNum++;

                }
            }
            
                
               // AfxMessageBox(str);
         
        }
       
    }
    
   // CHECK_HR(hr = MFCreateSourceReaderFromMediaSource(source, NULL, &reader));
   // CHECK_HR(hr = reader->GetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, &mediaType));
    //CHECK_HR(hr = mediaType->GetGUID(MF_MT_SUBTYPE, &subtype));
           // CHECK_HR(hr = MFGetAttributeSize(mediaType, MF_MT_FRAME_SIZE, width, height));

bail:
    SafeRelease(&source);
    SafeRelease(&reader);
    SafeRelease(&mediaType);
    SafeRelease(&pType);
    SafeRelease(&pSD);
    SafeRelease(&pPD);
    SafeRelease(&pHandler);
    return hr;
}