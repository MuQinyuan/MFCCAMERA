/* 
*/
#ifndef PLUGIN_WIN_MF_DISPLAY_WATCHER_H
#define PLUGIN_WIN_MF_DISPLAY_WATCHER_H

#include "../plugin_win_mf_config.h"

#include <new>
#include <mfapi.h>
#include <mfidl.h>
#include <Mferror.h>
#include <shlwapi.h>
#include <Evr.h>

class DisplayWatcher
{
public:
    DisplayWatcher(HWND hWnd, IMFMediaSink* pMediaSink, HRESULT &hr);
    virtual ~DisplayWatcher();

public:
    HRESULT Start();
 //   HRESULT SetFullscreen(BOOL bEnabled);
    HRESULT SetHwnd(HWND hWnd);
    HRESULT Stop();
	HRESULT GetSnapshot(BITMAPINFOHEADER *pInfo, BYTE **pData, DWORD *pdwSize);

	void    SetMessageParent( HWND hParentWnd ){ m_hParentWnd = hParentWnd; }
private:
    void UpdatePosition();
    static LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
    IMFVideoDisplayControl *m_pDisplayControl;
    HWND m_hWnd;
    WNDPROC m_pWndProc;
    BOOL m_bStarted;
    BOOL m_bFullScreen;
	HWND m_hParentWnd;
};

#endif /* PLUGIN_WIN_MF_DISPLAY_WATCHER_H */
