#pragma once

int tsk_thread_create( void** handle, void *(__cdecl *start) (void *), void *arg );
int tsk_thread_destroy( void** handle );
int tsk_thread_join( void ** handle );


