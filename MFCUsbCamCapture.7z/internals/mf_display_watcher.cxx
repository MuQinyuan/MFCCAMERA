/* 
*/
#include "stdafx.h"
#include "mf_display_watcher.h"
#include "mf_utils.h"

//#include "tsk_debug.h"

#include <assert.h>

DisplayWatcher::DisplayWatcher(HWND hWnd, IMFMediaSink* pMediaSink, HRESULT &hr)
    : m_pDisplayControl(NULL)
    , m_hWnd(hWnd)
    , m_pWndProc(NULL)
    , m_bStarted(FALSE)
    , m_bFullScreen(FALSE)
	, m_hParentWnd(NULL)
{
    IMFGetService *pService = NULL;

    CHECK_HR(hr = pMediaSink->QueryInterface(__uuidof(IMFGetService), (void**)&pService));
    CHECK_HR(hr = pService->GetService(MR_VIDEO_RENDER_SERVICE, __uuidof(IMFVideoDisplayControl), (void**)&m_pDisplayControl));
    CHECK_HR(hr = m_pDisplayControl->SetAspectRatioMode(MFVideoARMode_PreservePicture));
bail:
    SafeRelease(&pService);
}

DisplayWatcher::~DisplayWatcher()
{
    Stop();

    SafeRelease(&m_pDisplayControl);
}

HRESULT DisplayWatcher::Start()
{
    HRESULT hr = S_OK;
    HWND hWnd = m_hWnd; // save()
    CHECK_HR(hr = Stop());

    if((m_hWnd = hWnd) && m_pDisplayControl) {
        CHECK_HR(hr = m_pDisplayControl->SetVideoWindow(hWnd));

        BOOL ret = SetPropA(m_hWnd, "This", this);
        assert(ret);

#if _M_X64
        m_pWndProc = (WNDPROC)SetWindowLongPtr(m_hWnd, GWLP_WNDPROC, (LONG_PTR)DisplayWatcher::WndProc);
#else
        m_pWndProc = (WNDPROC)SetWindowLongPtr(m_hWnd, GWL_WNDPROC, (LONG)DisplayWatcher::WndProc);
#endif

        UpdatePosition(); // black screen if attached later
    }
    m_bStarted = TRUE;
bail:
    return hr;
}
//ȫ����Ҫ���ˣ�����������
//HRESULT DisplayWatcher::SetFullscreen(BOOL bEnabled)
//{
//    if(m_pDisplayControl) {
//        HRESULT hr =  m_pDisplayControl->SetFullscreen(bEnabled);
//        return hr;
//    }
//    return E_FAIL;
//}

HRESULT DisplayWatcher::SetHwnd(HWND hWnd)
{
   BOOL bWasStarted = m_bStarted;
    Stop();
    m_hWnd = hWnd;
    if(bWasStarted) {
        return Start();
    }
    return S_OK;
}

HRESULT DisplayWatcher::Stop()
{
    if(m_hWnd && m_pWndProc) {
        // Restore

#if _M_X64
        SetWindowLongPtr(m_hWnd, GWLP_WNDPROC, (LONG_PTR)m_pWndProc);
#else
        SetWindowLongPtr(m_hWnd, GWL_WNDPROC, (LONG)m_pWndProc);
#endif
    }
    m_hWnd = NULL;
    m_pWndProc = NULL;
    m_bStarted = FALSE;
    return S_OK;
}

HRESULT DisplayWatcher::GetSnapshot(BITMAPINFOHEADER *pInfo, BYTE **pData, DWORD *pdwSize)
{
	LONGLONG llTime = 0;
	HRESULT hr = E_FAIL;
	char pcArray[128];

	if (m_pDisplayControl && m_hWnd)
	{
		hr =  m_pDisplayControl->GetCurrentImage(pInfo, pData, pdwSize, &llTime);
		sprintf_s(pcArray, 128, "Snap, w: %d, h: %d, size: %d \n!!!", pInfo->biWidth, pInfo->biHeight, *pdwSize);
		OutputDebugStringA(pcArray);
	}
	
	return hr;
}

void DisplayWatcher::UpdatePosition()
{
    if(m_pDisplayControl && m_hWnd) {
        RECT rcDst = { 0, 0, 0, 0 };
        GetClientRect(m_hWnd, &rcDst);
        m_pDisplayControl->SetVideoPosition(NULL, &rcDst);
    }
}

LRESULT CALLBACK DisplayWatcher::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch(uMsg) {
    case WM_CREATE:
    case WM_SIZE:
    case WM_MOVE: {
        DisplayWatcher* This = dynamic_cast<DisplayWatcher*>((DisplayWatcher*)GetPropA(hWnd, "This"));
        if(This) {
            This->UpdatePosition();
        }
        break;
    }
	//case WM_LBUTTONDBLCLK:   �����ȫ�����ǲ�Ҫ���ˣ���Ϊ��ȫ���󣬸о�û�аѴ���ȫ����������Ϣ���������ˣ������Լ����ⲿ��ȫ����
	//	{
	//		DisplayWatcher* This = dynamic_cast<DisplayWatcher*>((DisplayWatcher*)GetPropA( hWnd, "This" ));
	//		if (This && This->m_pDisplayControl) {
	//			This->m_pDisplayControl->GetFullscreen(&(This->m_bFullScreen));
	//			HRESULT hr = This->m_pDisplayControl->SetFullscreen( !(This->m_bFullScreen) );
	//			//This->m_bFullScreen = SUCCEEDED( hr );
	//			
	//		}
	//		//break;
	//	}
    case WM_CHAR:
	case WM_KEYUP: 
	case WM_LBUTTONDBLCLK:
	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	case WM_RBUTTONDOWN:
	case WM_RBUTTONUP:
	case WM_MOUSEMOVE:
		{
			DisplayWatcher* This = dynamic_cast<DisplayWatcher*>((DisplayWatcher*)GetPropA( hWnd, "This" ));
			if (This) {
				if (This->m_hParentWnd && This->m_hParentWnd != This->m_hWnd )
					SendMessage( This->m_hParentWnd, uMsg, wParam, lParam );
			}

			break;
		}
    }
	
    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}