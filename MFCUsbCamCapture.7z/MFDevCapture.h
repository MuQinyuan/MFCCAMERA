#pragma once

#include "plugin_win_mf_config.h"
#include "internals/mf_utils.h"
#include "internals/mf_sample_grabber.h"
#include "internals/mf_devices.h"
#include "internals/mf_display_watcher.h"
//#include "internals/mf_custom_src.h"


class CMFDevCapture : public IMFMediaDataPro
{
public:
	CMFDevCapture();
	~CMFDevCapture();

	int MFInit(int iDeviceIndex, HWND hPlayeWnd, int width=0,int height=0,int fps=0,int format=0,int iRotation = 0);
	int AudioInit(int iDeviceIndex);
	int MFUnInit();
	
	int   MFSetPlayWnd( HWND hPlayWnd );
	void  MFSetMsgParent( HWND hParentWnd );
	int   MFSnapshot(char * lpFile);
	BOOL  MFIsStart(){ return m_bStarted;  }


	static void*  RunSessionThread( void *pArg );

	int   MFMediaDataCB(LONGLONG llSampleTime, LONGLONG llSampleDuration, const BYTE * pSampleBuffer, DWORD dwSampleSize);
public:
	int MFStart();
	int MFStop();
	
	bool m_bStarted, m_bPrepared;// , m_bMuted;

	IMFMediaSession *m_pSession;
private:
	void * m_ppTread[1];

	int32_t m_bitrate_bps; // used when encoder bundled only

	DeviceListVideo* m_pDeviceList;
	DeviceListAudio* m_pDeviceAudio;
	//MFCodecVideo *m_pEncoder;
	IMFMediaSource *m_pSource;
	
	SampleGrabberCB *m_pGrabberCB;
	IMFActivate *m_pSinkGrabber;
	IMFActivate *m_pSinkActivatePreview;
	DisplayWatcher* m_pWatcherPreview;
	IMFTopology *m_pTopology;
	IMFMediaType *m_pGrabberInputType;



	HWND m_hWndPreview;
	HWND m_hMsgParentWnd;
public:
	int	m_width;
	int m_height;
	int m_fps;
	int m_format;

	tmedia_chroma_e m_chroma;
};



