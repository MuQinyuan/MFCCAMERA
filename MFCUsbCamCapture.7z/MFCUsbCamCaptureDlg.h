﻿
// MFCUsbCamCaptureDlg.h: 头文件
//

#pragma once
#include "MFDevCapture.h"
#include "UsbCamLib.h"
// CMFCUsbCamCaptureDlg 对话框
class CMFCUsbCamCaptureDlg : public CDialogEx
{
// 构造
public:
	CMFCUsbCamCaptureDlg(CWnd* pParent = nullptr);	// 标准构造函数
	~CMFCUsbCamCaptureDlg();
// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MFCUSBCAMCAPTURE_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;
	DeviceListVideo* m_device;
	DeviceListAudio* m_auDevice;
	CMenu  m_PopupMenu,m_PopupAuMenu;
	CStatusBar m_statusBar;
protected:
	int m_deviceNumber;
	CMFDevCapture m_CapPreview;
	CString* m_strMsg;
	UINT m_EventType;
	CWinThread* MyThread;
	bool InitCamera();
	void DlgInit();
	bool GetDeviceCount(int* deviceNum);
	BOOL GetSonixCamVersion(CString& strVersion);
	BOOL GetUsbCamVersionXU(CString& strVersion,int vid,UsbGuid &xuGUID, unsigned char cs);
	BOOL BarToolFormat(CString& str);
	void MoveItem();
	int m_nItemID;
	int ** m_uSize;
	int m_width;
	int m_height;
	int m_fps;
	int m_format;
	bool m_flags;
	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnCommand(WPARAM  wParam, LPARAM  lParam);//虚拟函数重写
	afx_msg void OnBnClickedButton1();
	afx_msg void On32772();
	afx_msg void OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu);
	afx_msg BOOL OnDeviceChange(UINT nEventType, DWORD dwData);
	afx_msg void OnMenuRButtonUp(UINT nPos, CMenu* pMenu);
	
protected:
	afx_msg LRESULT OnSucessClick(WPARAM wParam, LPARAM lParam);

public:
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

public:
	static UINT MyThreadFunction(void* pParam);
	static int CreateDevMenu(CMFCUsbCamCaptureDlg* m_dlg);
	int CreateAuDevMenu();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
};
