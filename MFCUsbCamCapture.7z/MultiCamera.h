#ifndef __MULTICAMERA_H__
#define __MULTICAMERA_H__
#include "util.h"
#include "SonixCamera.h"
#include "AudioVideo.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	ö���豸
//����SonixCam_EnumDevice���������Ҫ���������ӿں�������Ҫ�ȵ���SonixCam_SelectDeviceѡ��Ҫ�������豸��Ϊ����
//SonixCam_EnumDevice��Ĭ��ָ�����һ��ö�ٵ����豸��
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		SonixCam_EnumDevice
*	Description:		ö������Sonix�豸
*	Parameters:	pCameras��CameraInfo����ָ�룬deviceNum�����ػ�õ��豸���� maxDeviceNum��sizeof(pCameras) / sizeof(CameraInfo)��
*	Return :			�ɹ�����	S_OK
*/
extern "C"  HRESULT WINAPI SonixCam_EnumDevice(CameraInfo pCameras[], long* deviceNum, long maxDeviceNum);


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	ѡ���豸
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
*	Function:		SonixCam_SelectDevice
*	Description:		ѡ��ָ�����豸
*	Parameters:	devIndex��Ҫѡ�е��豸�����ţ���һ���豸������0,�������ֵ��deviceNum - 1��
*	Return :			�ɹ�����	S_OK
*/
extern "C"  HRESULT WINAPI SonixCam_SelectDevice(long devIndex);




////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//���нӿں���֧�ֶ��߳�ͬʱ������ͬ���豸����������ڸ����̺߳����е�����¼������ͬʱ��¼�̼�
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
extern "C"  HRESULT WINAPI SonixCam_MulGetErrorCode(unsigned long devIndex, ERROR_CODE * ec);

extern "C"  HRESULT WINAPI SonixCam_MulGetCurBaseFilter(unsigned long devIndex, void **ppBaseFilter);

extern "C"  HRESULT WINAPI SonixCam_MulRestartDevice(unsigned long devIndex);

extern "C"  HRESULT WINAPI SonixCam_MulAsicRegisterRead(unsigned long devIndex, unsigned short addr, unsigned char pData[], long length);

extern "C"  HRESULT WINAPI SonixCam_MulAsicRegisterWrite(unsigned long devIndex, unsigned short addr, unsigned char pData[], long length);

extern "C"  HRESULT WINAPI SonixCam_MulSensorRegisterCustomRead(unsigned long devIndex, unsigned char slaveId, unsigned short  addr, unsigned char addrByteNumber, unsigned char pData[], unsigned char dataByteNumber, bool pollSCL = false);

extern "C"  HRESULT WINAPI SonixCam_MulSensorRegisterCustomWrite(unsigned long devIndex, unsigned char slaveId, unsigned short addr, unsigned char addrByteNumber, unsigned char pData[], unsigned char dataByteNumber, bool pollSCL = false);

extern "C"  HRESULT WINAPI SonixCam_MulSensorTwoRegisterCustomRead(unsigned long devIndex, unsigned char slaveId, unsigned short  addr, unsigned char addrByteNumber, unsigned char pData[], unsigned char dataByteNumber, bool pollSCL = false);

extern "C"  HRESULT WINAPI SonixCam_MulSensorTwoRegisterCustomWrite(unsigned long devIndex, unsigned char slaveId, unsigned short addr, unsigned char addrByteNumber, unsigned char pData[], unsigned char dataByteNumber, bool pollSCL = false);

extern "C"  HRESULT WINAPI SonixCam_MulGetNodeId(unsigned long devIndex, long* nodeId, long id);

extern "C"  HRESULT WINAPI SonixCam_MulXuRead(unsigned long devIndex, unsigned char pData[], unsigned int length, unsigned char cs, long nodeId, unsigned char unitID);

extern "C"  HRESULT WINAPI SonixCam_MulXuWrite(unsigned long devIndex, unsigned char pData[], unsigned int length, unsigned char cs, long nodeId, unsigned char unitID);

extern "C"  HRESULT WINAPI SonixCam_MulSerialFlashRead(unsigned long devIndex, long addr, unsigned char pData[], long length);

extern "C"  HRESULT WINAPI SonixCam_MulSerialFlashCustomRead(unsigned long devIndex, long addr, unsigned char pData[], long length);

extern "C"  HRESULT WINAPI SonixCam_MulSerialFlashSectorWrite(unsigned long devIndex, long addr, unsigned char pData[], long length, SERIAL_FLASH_TYPE sft);

extern "C"  HRESULT WINAPI SonixCam_MulSerialFlashWrite(unsigned long devIndex, long addr, unsigned char pData[], long length);

extern "C"  HRESULT WINAPI SonixCam_MulSerialFlashSectorCustomWrite(unsigned long devIndex, long addr, unsigned char pData[], long length, SERIAL_FLASH_TYPE sft);

extern "C"  HRESULT WINAPI SonixCam_MulGetSerialFlashType(unsigned long devIndex, SERIAL_FLASH_TYPE* sft, bool check = false);

extern "C"  HRESULT WINAPI SonixCam_MulGetParamTableAddr(unsigned long devIndex, long* paramTableAddr, long* paramTableLength, long* crcAddr, unsigned char *pFW = NULL);

extern "C"  HRESULT WINAPI SonixCam_MulGetFwVersion(unsigned long devIndex, unsigned char pData[], long length, bool bNormalExport = true);

extern "C"  HRESULT WINAPI SonixCam_MulGetFwVersionFromFile(unsigned long devIndex, unsigned char pFwFile[], unsigned char pData[], long length, bool bNormalExport = true);

extern "C"  HRESULT WINAPI SonixCam_MulGetManufacturer(unsigned long devIndex, unsigned char pData[], long length);

extern "C"  HRESULT WINAPI SonixCam_MulGetProduct(unsigned long devIndex, unsigned char pData[], long length);

extern "C"  HRESULT WINAPI SonixCam_MulGetVidPid(unsigned long devIndex, unsigned char pData[], long length);

extern "C"  HRESULT WINAPI SonixCam_MulGetString3(unsigned long devIndex, unsigned char pData[], long length);

extern "C"  HRESULT WINAPI SonixCam_MulGetInterface(unsigned long devIndex, unsigned char pData[], long length);

extern "C"  HRESULT WINAPI SonixCam_MulGetSerialNumber(unsigned long devIndex, unsigned char pData[], long length);

extern "C"  HRESULT WINAPI SonixCam_MulGetBCD(unsigned long devIndex, unsigned char pData[], long length = 2);

extern "C"  HRESULT WINAPI SonixCam_MulGetAsicRomType(unsigned long devIndex, ASIC_ROM_TYPE* romType, unsigned char* chipID);

extern "C"  HRESULT WINAPI SonixCam_MulCheckStreamOn(unsigned long devIndex, int* rVal);

extern "C"  HRESULT WINAPI SonixCam_MulBurnerFW(unsigned long devIndex, unsigned char pFwBuffer[], long lFwLength, SonixCam_SetProgress setProgress, void *ptrClass, SERIAL_FLASH_TYPE sft, bool bFullCheckFW = false);

extern "C"  HRESULT WINAPI SonixCam_MulWriteFwToFlash(unsigned long devIndex, unsigned char pFwBuffer[], long lFwLength, SonixCam_SetProgress setProgress, void *ptrClass, bool bFullCheckFW = false);

extern "C"  HRESULT WINAPI SonixCam_MulExportFW(unsigned long devIndex, unsigned char  pFwBuffer[], long lFwLength, SonixCam_SetProgress setProgress, void *ptrClass);

extern "C"  HRESULT WINAPI SonixCam_MulDisableSerialFlashWriteProtect(unsigned long devIndex, SERIAL_FLASH_TYPE sft);

extern "C"  HRESULT WINAPI SonixCam_MulEraseSerialFlash(unsigned long devIndex, SERIAL_FLASH_TYPE sft);

extern "C"  HRESULT WINAPI SonixCam_MulEraseSectorFlash(unsigned long devIndex, long addr, SERIAL_FLASH_TYPE sft);

extern "C"  HRESULT WINAPI SonixCam_MulEraseBlockFlash(unsigned long devIndex, long addr, SERIAL_FLASH_TYPE sft);

extern "C"  HRESULT WINAPI SonixCam_MulFullCheckFW(unsigned long devIndex, unsigned char pFwBuffer[], long fwLength, SonixCam_SetProgress setProgress, void *ptrClass);

extern "C"  HRESULT WINAPI SonixCam_MulCustomBurnerFW(unsigned long devIndex, ChangeParamInfo * paramInfo, unsigned char pFwBuffer[], long lFwLength, SonixCam_SetProgress setProgress, void *ptrClass, SERIAL_FLASH_TYPE sft, bool bFullCheckFW = false);

extern "C"  HRESULT WINAPI SonixCam_MulSetParamTableFromFWFile(unsigned long devIndex, unsigned char pFW[], long lFwLength, ChangeParamInfo* paramInfo, SonixCam_SetProgress setProgress, void *ptrClass, SERIAL_FLASH_TYPE sft, char* pLogFilePath, bool bFullCheckFW = false);

// Audio Video Class

extern "C"  HRESULT WINAPI SonixCam_MulOpenCamera(unsigned long devIndex, HWND hWnd, long lNotifyWinMsg, SonixCam_Grab pGrab);

extern "C"  HRESULT WINAPI SonixCam_MulCloseCamera(unsigned long devIndex);

extern "C"  HRESULT WINAPI SonixCam_MulIsOpenCamera(unsigned long devIndex, bool* bOpening);

extern "C"  HRESULT WINAPI SonixCam_MulIsPreviewing(unsigned long devIndex, bool* bPreviewing);

extern "C"  HRESULT WINAPI SonixCam_MulStartPreview(unsigned long devIndex);

extern "C"  HRESULT WINAPI SonixCam_MulPausePreview(unsigned long devIndex);

extern "C"  HRESULT WINAPI SonixCam_MulStopPreview(unsigned long devIndex);

extern "C"  HRESULT WINAPI SonixCam_MulAdjustPreviewWindow(unsigned long devIndex, bool bVisible);

extern "C"  HRESULT WINAPI SonixCam_MulGetPreviewResolutionCount(unsigned long devIndex, long* ResolutionCount);

extern "C"  HRESULT WINAPI SonixCam_MulGetPreviewResolutionInfo(unsigned long devIndex, unsigned char ResolutionNum, VideoOutFormat * OutFormat);

extern "C"  HRESULT WINAPI SonixCam_MulGetCurrentPreviewResolutionInfo(unsigned long devIndex, VideoOutFormat * OutFormat);

extern "C"  HRESULT WINAPI SonixCam_MulSetVideoFormat(unsigned long devIndex, long lNotifyWinMsg, unsigned char ResolutionNum);

extern "C"  HRESULT WINAPI SonixCam_MulGetStillResolutionCount(unsigned long devIndex, long* ResolutionCount);

extern "C"  HRESULT WINAPI SonixCam_MulGetStillResolutionInfo(unsigned long devIndex, unsigned char ResolutionNum, VideoOutFormat * OutFormat);

extern "C"  HRESULT WINAPI SonixCam_MulSetStillSnapShotFormat(unsigned long devIndex, long lNotifyWinMsg, unsigned char ResolutionNum);

extern "C"  HRESULT WINAPI SonixCam_MulStillPinSnapShot(unsigned long devIndex, SonixCam_SnapShotGrab grab);

extern "C"  HRESULT WINAPI SonixCam_MulPropertyGetRange(unsigned long devIndex, CameraProperty uiProperty, long* pMin, long* pMax,
														long* pSteppingDelta,
														long* pDefault,
														PropertyFlags * pCapsFlags
														);

extern "C"  HRESULT WINAPI SonixCam_MulPropertyGet(unsigned long devIndex, CameraProperty uiProperty, long* lValue, PropertyFlags * Flags);

extern "C"  HRESULT WINAPI SonixCam_MulPropertySet(unsigned long devIndex, CameraProperty uiProperty, long lValue, PropertyFlags Flags);

extern "C"  HRESULT WINAPI SonixCam_MulControlGetRange(unsigned long devIndex, CameraControl uiControl, long* pMin, long* pMax,
													   long* pSteppingDelta,
													   long* pDefault,
													   PropertyFlags * pCapsFlags
													   );

extern "C"  HRESULT WINAPI SonixCam_MulControlGet(unsigned long devIndex, CameraControl uiControl, long* lValue, PropertyFlags * Flags);

extern "C"  HRESULT WINAPI SonixCam_MulControlSet(unsigned long devIndex, CameraControl uiControl, long lValue, PropertyFlags Flags);

extern "C"  HRESULT WINAPI SonixCam_MulGetFrameSpeed(unsigned long devIndex, double* dFramerate);

extern "C"  HRESULT WINAPI SonixCam_MulSetFrameSpeed(unsigned long devIndex, double dFramerate);

extern "C"  HRESULT WINAPI SonixCam_MulGetPowerLine(unsigned long devIndex, PowerLine* PowerLine);

extern "C"  HRESULT WINAPI SonixCam_MulSetPowerLine(unsigned long devIndex, PowerLine PowerLine);

extern "C"  HRESULT WINAPI SonixCam_MulGetAutoExposurePriority(unsigned long devIndex, long* check);

extern "C"  HRESULT WINAPI SonixCam_MulSetAutoExposurePriority(unsigned long devIndex, long check);


#endif
